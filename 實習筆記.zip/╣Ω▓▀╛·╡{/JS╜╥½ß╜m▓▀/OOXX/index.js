// 程式碼寫這裡
window.onload=function(){
  let arr = [[], [], [], [], [], [], [], [], []];//記錄每一個步驟的資料
  const cells = document.querySelectorAll(".cell");//九宮格
  const statusText = document.querySelector("#statusText");//Next player:
  const restartBtn = document.querySelector("#restartBtn");//Go to game start
  const winConditions = [
      [0, 1, 2],
      [3, 4, 5],
      [6, 7, 8],
      [0, 3, 6],
      [1, 4, 7],
      [2, 5, 8],
      [0, 4, 8],
      [2, 4, 6]
  ];//判別連線的條件
  let options = ["", "", "", "", "", "", "", "", ""];//紀錄每格的資訊
  let currentPlayer = "X";//以 X 先手
  let running = false;
  turn = 0;

  cells.forEach(cell => cell.addEventListener("click", cellClicked));
  restartBtn.addEventListener("click", restartGame);
  statusText.textContent = `Next player:${currentPlayer}`;
  running = true;//遊戲開始

  function cellClicked(){//點選九宮格
    const cellIndex = this.getAttribute("cellIndex");

    if(options[cellIndex] != "" || !running){//判斷格子是否被占用
      return;
    }else{
      options[cellIndex] = currentPlayer;
      this.textContent = currentPlayer;//畫OX

      stepButton();
      checkWinner();
    }
  }
  function stepButton(){
    turn++;
    
    let temp = [...options];
    arr[turn] = temp;
    
    const todo = document.createElement('li');
    todo.classList.add('Btn-item');
    todo.innerHTML =`<button id="stepBtn" onClick="goToTurn(${turn})">Go to Move ${turn}</button>`;
    document.querySelector('.todo-list').appendChild(todo);//生成跳轉按鈕
    
    // const stepBtn = document.querySelector("#stepBtn");
    // stepBtn.addEventListener("click", goToTurn);
    console.log(options);
  }
  function changePlayer(){//Next player:X
    currentPlayer = (currentPlayer == "X") ? "O" : "X";
    statusText.textContent = `Next player:${currentPlayer}`;
  }
  function checkWinner(){//判別勝負
    let roundWon = false;//遊戲結束

    for(let i = 0; i < winConditions.length; i++){
      const condition = winConditions[i];
      const cellA = options[condition[0]];
      const cellB = options[condition[1]];
      const cellC = options[condition[2]];

      if(cellA == "" || cellB == "" || cellC == ""){
        continue;
      }
      if(cellA == cellB && cellB == cellC){
        roundWon = true;
        break;
      }
    }

    if(roundWon){
      statusText.textContent = `Winner:${currentPlayer}`;
      running = false;
    }
    else if(!options.includes("")){//每格都有值
      statusText.textContent = `平手`;
      running = false;
    }
    else{
      changePlayer();
    }
  }
  function restartGame(){//重設遊戲設置
    currentPlayer = "X";
    options = ["", "", "", "", "", "", "", "", ""];
    statusText.textContent = `Next player:${currentPlayer}`;
    cells.forEach(cell => cell.textContent = "");
    running = true;
    turn = 0;
  }
  function goToTurn(turn){//跳轉回合
    let arrStep = turn;
    cells.forEach((e,index) => e.textContent = arr[arrStep][index]);
    checkWinner();
  }
}