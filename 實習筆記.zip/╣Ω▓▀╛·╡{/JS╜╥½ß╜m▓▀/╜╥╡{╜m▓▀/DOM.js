document.addEventListener('DOMContentLoaded',() => {
    //抓取元素兩種方法:getElement or querySelector
    // let d1 = document.getElementById('doll-1');
    // let d2 = document.querySelector('#doll-2');//.抓class #抓id
    
    // //抓同個 class 裡的元素
    // let doll = document.getElementsByClassName('doll');//HTMLcolletion 元素的集合體
    // let doll2 = document.querySelectorAll('.doll');//nodelist node的集合體
    // console.log(doll);
    // console.log(doll2);
    
    // //替換內容
    // d1.textContent = '娃娃-1';
    // d1.innerHTML = "<h1>大娃娃</h1>";
    // d1.style.color = 'red';
    
    // let clickme = () => {
    //     console.log('被案了');
    // }
    let btn = document.querySelector('#btn');
    // btn.addEventListener('click',clickme);//把 function 當引數不用加括號
    // //clickme 是 call back 回呼函式 當事件(例如click)發生時再執行的函式

    //on 系列
    btn.onclick = () => {
        console.log('1');
    }
    btn.onclick = () => {
        console.log('2');
    }
    //on 系列會以最後的覆蓋之前的

    //addEventListener 系列
    btn.addEventListener('click',() => {
        console.log('1');
    });
    btn.addEventListener('click',() => {
        console.log('2');
    });
    //addEventListener 系列會疊加以往的
    
    let link = document.querySelector('#link');
    link.addEventListener('click',(e) => {
        console.log('不準案');
        e.preventDefault();//停止跳轉預設行為
    })
})