const api = "https://jsonplaceholder.typicode.com/posts"

// 作法一 XMLHttpRequest
// const rep = new XMLHttpRequest();//存取的物件
// rep.addEventListener('load',() => {
//     const posts = JSON.parse(rep.responseText);
//     posts.forEach((posts) => {
//         console.log(posts.title);
//     });
// })

// rep.open('GET',api);//連結 api
// rep.send();//發送請求

// 作法二 fetch
// fetch(api)
// .then((resp) => {
//     return resp.json();//接收json
// })
// .then((data) => {
//     data.forEach(data => {
//         console.log(data.title);//印出json
//     });
// });

// 作法三 async/await
async function getPost(){
    const resp = await fetch(api);
    const posts = await resp.json();

    posts.forEach((posts) => {
        console.log(posts);
    });
}

getPost();
console.log('go!');