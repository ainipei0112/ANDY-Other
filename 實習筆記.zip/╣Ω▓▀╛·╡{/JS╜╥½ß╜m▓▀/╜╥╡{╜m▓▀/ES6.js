document.addEventListener('DOMContentLoaded',() => {
    //一般 function
    // function addNumber (a,b) {
    //     return a+b;
    // }

    //匿名函式
    // const addNumber = function (a,b) {
    //     return a+b;
    // }

    //箭頭函式
    // const addNumber = (a,b) => {
    //     return a+b;
    // }
    
    //簡易寫法 可以省略 return
    // const addNumber = (a,b) => a+b;

    // console.log(addNumber(1,2));

    //解構
    // const user = {
    //     name:'悟空',
    //     age:18
    // }
    // const {name,age} = user;
    // console.log(name);

    //新增DOM
    // const hello = document.querySelector("#hello");

    // const h = document.createElement('h1');
    // h.textContent = 'hi'

    // hello.appendChild(h);

    //刪除DOM
    // const removebtn = document.querySelector('#removebtn');

    // removebtn.onclick = () => {
    //     let lastone = document.querySelector('li:last-child');
    //     let u = document.querySelector('ul');
    //     console.log(lastone);
    //     if (lastone !== null) {
    //         // lastone.remove();//元素刪除自己
    //         u.removeChild(lastone);//父元素刪除子元素
    //     } else {
    //         console.log('我沒了');
    //     }
    // };
    //取得上下、同層DOM
    let lastone = document.querySelector('li:last-child');
    let u = document.querySelector('ul');
    // console.log(lastone.parentElement);//取得上層
    // console.log(u.children);//取得下層
    // console.log(lastone.previousElementSibling);//取得同層上個
    // console.log(lastone.nextElementSibling);//取得同層下個

    //安插DOM
    u.insertAdjacentElement("afterbegin", lastone);
    //四個位置 beforebegin afterbegin beforeend afterend
})