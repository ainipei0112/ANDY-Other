// 程式碼寫這裡
document.addEventListener('DOMContentLoaded',() => {
    const api = "https://tcgbusfs.blob.core.windows.net/dotapp/youbike/v2/youbike_immediate.json";
    const Keyword = document.querySelector('#searchKeyword');
    const Form = document.querySelector('#searchForm');
    async function getPost(){
        const resp = await fetch(api);
        const posts = await resp.json();
        const query = Keyword.value.trim();
        const siteList = document.querySelector('.siteList');

        if (query !== '') {
            const res = posts.filter(posts => {
                return posts.ar.includes(query);
            });
            
            res.forEach(posts => {
                const sna = posts.sna.substr(11);
                const bemp = posts.bemp;
                const ar = posts.ar;
                const item = `<li class="list-group-item fs-5">
                            <i class="fas fa-bicycle"></i>
                            ${sna} (${bemp})<br>
                            <small class="text-muted">${ar}</small>
                        </li>`;

                siteList.insertAdjacentHTML("beforeend",item);
            });
        };
    };

    Form.addEventListener("submit",(e) => {
        e.preventDefault();
        
        getPost();
    });
});