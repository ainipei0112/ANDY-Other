// 程式碼寫這裡
const timer = document.querySelector(".timer");
const word = document.querySelector(".word");
let ts = prompt("請輸入秒數"),timeid,running = 0,stop = 0;
updateTime(ts);//初始數字
word.textContent = `按 Enter 開始`;

function updateTime(ts) {//時光飛逝
    let min = String(Math.floor(ts/60)).padStart(2,"0");
    let sec = String(ts%60).padStart(2,"0");
    timer.textContent = `${min}:${sec}`;
}

function initTimer() {//初始化計時器
    word.textContent = '';
    timeid = setInterval(() => {
        if (ts>0) {
        updateTime(--ts);
        } else {
            clearInterval(timeid);
            let sound = new Audio("sounds/news.mp3");
            sound.play();
        }
    },1000);
}

function start() {//開始
    running = 1;
    console.log('繼續');
    initTimer();
}

function pause() {//暫停
    running = 0;
    console.log('暫停');
    clearInterval(timeid);
}

document.onkeydown = (e) => {//按鍵
    if (e.key === "Enter" && running == 0) {
        running = 1;
        initTimer();
    } else if (e.key === " ") {
        if (running == 1) {
            pause();
        } else {
            start();
        }
    }
}