// 程式碼寫這裡
const carousel = document.querySelector(".carousel");
//從 carousel 防止抓到其他區域同名 DOM 元素
const track = carousel.querySelector(".slide-track");//照片區域
const slides = carousel.querySelectorAll(".slide");//各張照片
const nextBtn = carousel.querySelector(".next-btn");//左右按鈕
const prevBtn = carousel.querySelector(".prev-btn");
const navigator = carousel.querySelector(".navigator");//點點區
const indicators = navigator.querySelectorAll(".indicator");//點點按紐
const w = track.clientWidth;
let currentIndex = 0;

//照片區域
function setupslides() {//照片區域寬度
    slides.forEach((slide,i) => {
        slide.style.left = `${i*w}px`
    })
}

function moveSlide(Index) {//移動照片
    track.style.transform = `translateX(-${Index*w}px)`;
    updateNavigatorButtons(Index);
    updateIndicator(Index);
}

//頭尾箭頭隱藏
function updateNavigatorButtons(Index) {
    if (Index == 0) {
        prevBtn.classList.add("hide")
        nextBtn.classList.remove("hide")
    } else if (Index == slides.length - 1) {
        prevBtn.classList.remove("hide")
        nextBtn.classList.add("hide")
    } else {
        nextBtn.classList.remove("hide")
        prevBtn.classList.remove("hide")
    }
}

//切換點點
function updateIndicator(index) {
    indicators.forEach((indicator) => {
        if (indicator.dataset.index == index) {
        indicator.classList.add("active")
        } else {
        indicator.classList.remove("active")
        }
    })
}

//按鈕
nextBtn.onclick = () => {
    currentIndex++;
    moveSlide(currentIndex);
};

prevBtn.onclick = () => {
    currentIndex--;
    moveSlide(currentIndex);
};

//點點
navigator.onclick = (e) => {
    if (e.target.matches("button")) {
      const dan = e.target;//點點
      currentIndex = dan.dataset.index;

      moveSlide(currentIndex);
    }
};

//初始化
setupslides();
prevBtn.classList.add("hide");