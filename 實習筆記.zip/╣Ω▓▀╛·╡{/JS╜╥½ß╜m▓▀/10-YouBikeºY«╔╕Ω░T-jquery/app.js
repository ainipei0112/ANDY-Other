// 程式碼寫這裡
$().ready(() => {
    const api = "https://tcgbusfs.blob.core.windows.net/dotapp/youbike/v2/youbike_immediate.json";
    const Keyword = $("#searchKeyword")
    const Form = $('#searchForm');
    
    // $.ajax(api).done(function(res) {
    //     console.log(res);
    // });
    
    
    function getPost(){
        const query = Keyword.val();

        if (query !== '') {
            $.ajax(api).done((res) => {
                const siteList = $('.siteList');
                res.filter(res => {
                    return res.ar.includes(query);
                }).forEach(res => {
                    const sna = res.sna.substr(11);
                    const bemp = res.bemp;
                    const ar = res.ar;
                    const item = `<li class="list-group-item fs-5">
                                <i class="fas fa-bicycle"></i>
                                ${sna} (${bemp})<br>
                                <small class="text-muted">${ar}</small>
                            </li>`;
                    siteList.append(item);
                });
            
            });
        };
    };

    Form.submit((e) => {
        e.preventDefault();
        
        getPost();
    });
});