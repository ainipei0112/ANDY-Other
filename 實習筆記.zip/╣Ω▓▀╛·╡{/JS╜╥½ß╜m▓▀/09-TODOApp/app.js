// 程式碼寫這裡
window.onload=function(){
    var addBtn = document.querySelector('#addBtn');
    var closeBtn = document.querySelector('.closeBtn');
    var todo = document.querySelector('.todo-list');
    var taskInput = document.querySelector('#taskInput');

    function add(){
        var inputValue = taskInput.value;
        if (inputValue.trim().length === 0) return;
        const todo = document.createElement('li');
        todo.classList.add('todo-item');
        todo.innerHTML =    `<span class="item">${inputValue}</span>
                            <button class="closeBtn">X</button>`;
        document.querySelector('.todo-list').appendChild(todo);
        taskInput.value = '';
    }
    function del(e){
        e.target.parentNode.remove();
    }

    addBtn.addEventListener('click',add);
    todo.addEventListener('click',del);
}