// 程式碼寫在這裡
window.onload=function(){
    var minus = document.querySelector('#minus');
    var plus = document.querySelector('#plus');
    var counter = parseInt(document.querySelector('#counter').value);

    function up(){
        var num = document.getElementById("counter");
        num.value = ++counter;
    }
    function down(){
        if(counter>0){
            var num = document.getElementById("counter");
            num.value = --counter;
        }else{
            alert('不能小於0');
        }
    }

    plus.addEventListener('click',up);
    minus.addEventListener('click',down);
}