// 程式碼寫在這裡
// 提示：BMI = 體重(kg) / 身高(m) 平方
window.onload=function(){
    var btn = document.querySelector('.btn');
    btn.addEventListener('click',calculateBMI);

    function calculateBMI(){
        var resultText = document.querySelector('#resultText');
        var str='';
        var height = parseInt(document.getElementById('bodyHeight').value)/100;
        var weight = parseInt(document.getElementById('bodyWeight').value);
        var height2 = height*height;
        var BMI = weight/height2;
        
        BMI = BMI.toFixed(2);
        resultText.innerHTML = BMI;
    }
}