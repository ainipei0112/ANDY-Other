// 程式碼寫這裡
const operator = document.querySelectorAll('.operator-key'); 