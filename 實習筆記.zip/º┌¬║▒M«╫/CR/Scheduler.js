let hotkey = null;
let ac = true;
let grouptmp = [];
let emptmp = [];
let datagroup = [];
let defdatagroup = [];
let IsUpdate = true;
let calendar = null;
let myMask = null;
let eventlog = [];
let indexlog = -1;
let calendarSetting = [
	{ id: '2-0050', color: '#3f51b5' },
	{ id: '2-0051', color: '#673ab7' },
	{ id: '2-0052', color: '#2196f3' },
	{ id: '2-0053', color: '#43a047' },
	{ id: '2-0054', color: '#795548' },
	{ id: '2-0059', color: '#f44336' },
	{ id: '2-0066', color: '#e91e63' },
	{ id: '2-0067', color: '#9c27b0' },
	{ id: '2-0234', color: '#009688' },
	{ id: '2-0235', color: '#616161' },
	{ id: '3-0500', color: '#607d8b' },
];
let toolbarevent = [];
let schedulerEMPgroupid = '';
let MyHoliday = [];
let MyRest = [];
let loadEventData = [];
let defsavedata = [];
let errmsg = null;
Ext.define('MyModel', {
	extend: 'Ext.data.Model',
	fields: [
		{ name: 'id', type: 'string' },
		{ name: 'title', type: 'string' },
		{ name: 'group', type: 'string' },
		{ name: 'seq', type: 'integer' },
	],
});

let companyId = '';

Ext.define('MyGroup', {
	extend: 'Ext.data.Model',
	fields: [
		{ name: 'id', type: 'string' },
		{ name: 'group', type: 'string' },
	],
});

Ext.define('MyScheduleType', {
	extend: 'Ext.data.Model',
	fields: [
		{ name: 'id', type: 'string' },
		{ name: 'type', type: 'string' },
		{ name: 'wh', type: 'integer' },
		{ name: 'name', type: 'string' },
		{ name: 'color', type: 'string' },
	],
});

Ext.define('MyTimeRange', {
	extend: 'Ext.data.Model',
	fields: [{ name: 'tdisplay', type: 'string', def: 'string' }],
});

Ext.define('MyDays', {
	extend: 'Ext.data.Model',
	fields: [
		{ name: 'id', type: 'string' },
		{ name: 'days', type: 'string' },
	],
});

const emp_error_store = new Ext.data.JsonStore({
	fields: [
		{
			name: 'EMPLOYEE_NO',
			type: 'int',
		},
		{
			name: 'EMPLOYEE_NAME',
			type: 'string',
		},
		{
			name: 'MESSAGES',
			type: 'string',
		},
	],
	proxy: {
		type: 'memory',
		enablePaging: true,
		reader: {
			type: 'json',
			root: 'data',
			totalProperty: 'totalCount',
		},
	},
});

const emp_days_store = Ext.create('Ext.data.Store', {
	//全部要查詢的
	model: 'MyDays',
	pageSize: 99,
	proxy: {
		type: 'memory',
		enablePaging: true,
		reader: {
			type: 'json',
			root: 'data',
			totalProperty: 'totalCount',
		},
	},
});

const emp_store = Ext.create('Ext.data.Store', {
	//全部要查詢的
	model: 'MyModel',
	pageSize: 99,
	proxy: {
		type: 'memory',
		enablePaging: true,
		reader: {
			type: 'json',
			root: 'data',
			totalProperty: 'totalCount',
		},
	},
});

const emp_store1 = Ext.create('Ext.data.Store', {
	//全部要查詢的
	model: 'MyModel',
	pageSize: 99,
	proxy: {
		type: 'memory',
		enablePaging: true,
		reader: {
			type: 'json',
			root: 'data',
			totalProperty: 'totalCount',
		},
	},
});

const emp_group_store = Ext.create('Ext.data.Store', {
	//全部要查詢的
	model: 'MyGroup',
	pageSize: 99,
	proxy: {
		type: 'memory',
		enablePaging: true,
		reader: {
			type: 'json',
			root: 'data',
			totalProperty: 'totalCount',
		},
	},
});

const emp_schetype_store = Ext.create('Ext.data.Store', {
	//全部要查詢的
	model: 'MyScheduleType',
	pageSize: 99,
	proxy: {
		type: 'memory',
		enablePaging: true,
		reader: {
			type: 'json',
			root: 'data',
			totalProperty: 'totalCount',
		},
	},
});

const emp_trange_store = Ext.create('Ext.data.Store', {
	//全部要查詢的
	model: 'MyTimeRange',
	pageSize: 99,
	proxy: {
		type: 'memory',
		enablePaging: true,
		reader: {
			type: 'json',
			root: 'data',
			totalProperty: 'totalCount',
		},
	},
});

//頁面：工具列和排班表
const schedulePanel = Ext.create('Ext.Panel', {
	title: 'Shift Planner',
	//closable: 'closable',
	id: 'MySchedulerTab',
	//layout : 'border',
	region: 'center',
	//suspendLayout: false,
	listeners: {
		beforeclose: function (tabPanel) {
			if (SchedulerEditorWindow) {
				SchedulerEditorWindow.destroy();
			}
			if (SchedulerEMPWindow) {
				SchedulerEMPWindow.destroy();
			}
			if (SchedulerCopyWindow) {
				SchedulerCopyWindow.destroy();
			}
			if (SchedulerClickWindow) {
				SchedulerClickWindow.destroy();
			}
		},
		afterrender: function () {
			myMask = new Ext.LoadMask({
				msg: 'Please wait...',
				target: schedulePanel,
			});
			ReaderSchedule();
		},
		beforeshow: function () {
			//getHoliday();
		},
	},
	border: false,
	//layout: 'fit',
	items: [
		{
			xtype: 'container',
			width: '100%',
			flex: 2,
			layout: {
				type: 'vbox',
				//align: 'stretch' // Child items are stretched to full width
			},
			items: [
				{
					html: `<div id="Mytoolbar" tabindex="0" class="mb-3 mt-3 main-header"  ></div>`,
					border: false,
					height: 150,
					width: '100%',
					autoScroll: true,
				},
			],
		},
		{
			html: `<div id="Mycalendar" tabindex="0" class="ml-3 mr-3" height: 100%;></div>`,
			border: false,
			height: window.innerHeight - 200,
			width: '100%',
			autoScroll: true,
		},
	],
});

const getprivilege = async () => {
	// return fetch('./Scheduler.php?action=api_get_privilege&' + new URLSearchParams({
	//     //userGroup: userGroup,
	// }), {
	//     method: "GET",
	//     headers: new Headers({
	//         'Content-Type': 'application/json',
	//     })
	// })
	//     .then(response => response.json())
	//     .then((data) => data.data.SCHEDULE_FLAG ==="Y" || false);

	return ac;
};

//儲存結果畫面
const emp_error_window = Ext.create('Ext.window.Window', {
	//window
	id: 'emp_error_window',
	title: 'Scheduler Save Result',
	height: 310,
	width: 870,
	resizable: false,
	modal: true,
	closeAction: 'close',
	layout: {
		type: 'vbox',
		align: 'stretch',
	},
	items: [
		{
			xtype: 'grid',
			id: 'emp_grid_id',
			border: false,
			viewConfig: {
				enableTextSelection: true,
			},
			store: emp_error_store,
			displayInfo: true,
			flex: 2, //用來調比例
			columns: [
				{
					text: 'Employee No',
					dataIndex: 'EMPLOYEE_NO',
					width: 120,
					sortable: false,
				},
				{
					text: 'Employee Name',
					dataIndex: 'EMPLOYEE_NAME',
					width: 120,
					sortable: false,
				},
				{
					text: 'Message',
					dataIndex: 'MESSAGES',
					sortable: false,
					width: 600,
				},
			],
		},
	],
});

//排班資料編輯畫面
const SchedulerEditorWindow = Ext.create('Ext.window.Window', {
	title: 'Scheduler Editor',
	//width: 600,
	resizable: false,
	layout: 'fit',
	modal: true, //Disable底視窗畫面
	closeAction: 'close', //close 或 hide
	listeners: {
		beforeclose: function (win) {},
	},
	items: {
		// Let's put an empty grid in just to illustrate fit layout
		xtype: 'panel',
		frame: true,
		flex: 1,
		items: [
			{
				//width: 600,
				xtype: 'fieldcontainer',
				layout: {
					type: 'vbox',
				},
				items: [
					{
						xtype: 'fieldset',
						//title: 'Editor',
						collapsible: false,
						border: false,
						margin: '5 5 5 5',
						items: [
							{
								xtype: 'fieldcontainer',
								layout: {
									type: 'hbox',
									//defaultMargins: {top: 5, right: 0, bottom: 5, left: 0}
								},
								items: [
									{
										xtype: 'datefield',
										//width: 250,
										fieldLabel: 'Start Date',
										labelAlign: 'right',
										id: 'scheduler_start_date',
										format: 'Y-m-d',
										dateFormat: 'Y-m-d',
										renderer: function (val, meta, record) {
											return Ext.Date.format(val, 'Y-m-d');
										},
									},
									{
										xtype: 'label',
										labelWidth: '100%',
										text: '　~　',
									},
									{
										xtype: 'datefield',
										//width: 150,
										labelWidth: '100%',
										fieldLabel: 'End Date',
										labelAlign: 'right',
										id: 'scheduler_end_date',
										format: 'Y-m-d',
										dateFormat: 'Y-m-d',
										renderer: function (val, meta, record) {
											return Ext.Date.format(val, 'Y-m-d');
										},
									},
								],
							},
							{
								xtype: 'combo',
								//width: 250,
								fieldLabel: 'Employee',
								name: 'EMP_name',
								labelAlign: 'right',
								store: emp_store,
								queryMode: 'local',
								filter: true,
								lazyRender: true,
								typeAhead: true,
								selectOnFocus: true,
								forceSelection: true,
								value: '',
								loadMask: false,
								displayField: 'title', //顯示用
								valueField: 'id', //
								id: 'scheduler_EMP_id',
								disabledCls: 'my-item-disabled',
							},
							{
								xtype: 'combo',
								//width: 250,
								fieldLabel: 'Schedule Type',
								labelAlign: 'right',
								store: emp_schetype_store,
								queryMode: 'local',
								filter: true,
								lazyRender: true,
								typeAhead: true,
								selectOnFocus: true,
								forceSelection: true,
								value: '',
								loadMask: false,
								displayField: 'type', //顯示用
								valueField: 'id', //
								id: 'scheduler_sche_type_id',
								disabledCls: 'my-item-disabled',
								listeners: {
									change: function (thisCmp, newValue, oldValue, eOpts) {
										if (newValue === '3-0500') {
											Ext.getCmp('scheduler_h1_id').setValue(true);
										} else {
											Ext.getCmp('scheduler_h1_id').setValue(false);
										}

										if (newValue === '2-0051') {
											Ext.getCmp('scheduler_oncall_id').setValue(true);
										} else {
											Ext.getCmp('scheduler_oncall_id').setValue(false);
										}

										const chk = ['2-0050', '2-0051', '3-0500'];

										if (chk.includes(newValue)) {
											Ext.getCmp('scheduler_oncall_id').setDisabled(false);
										} else {
											Ext.getCmp('scheduler_oncall_id').setDisabled(true);
										}
										if (SchedulerEditorWindow.myExtraParams) {
											SchedulerEditorWindow.myExtraParams.sid === newValue ? getTimeRange(SchedulerEditorWindow.myExtraParams.timerange) : getTimeRange();
										} else getTimeRange();
									},
								},
							},
							{
								xtype: 'combo',
								//width: 250,
								fieldLabel: 'Time Range',
								labelAlign: 'right',
								store: emp_trange_store,
								queryMode: 'local',
								filter: true,
								lazyRender: true,
								typeAhead: true,
								selectOnFocus: true,
								forceSelection: true,
								value: '',
								loadMask: false,
								displayField: 'tdisplay', //顯示用
								valueField: 'id', //
								id: 'scheduler_time_range_id',
								disabledCls: 'my-item-disabled',
							},
							{
								xtype: 'fieldcontainer',
								fieldLabel: '當日 On Call',
								labelWidth: 80,
								labelAlign: 'right',
								layout: {
									type: 'hbox',
								},
								items: [
									{
										xtype: 'checkboxgroup',
										width: 230,
										items: [
											{
												id: 'scheduler_oncall_id',
												value: false,
											},
										],
									},
								],
							},
							{
								xtype: 'fieldcontainer',
								fieldLabel: '當日休息日',
								labelWidth: 80,
								labelAlign: 'right',
								layout: {
									type: 'hbox',
								},
								items: [
									{
										xtype: 'checkboxgroup',
										width: 230,
										items: [
											{
												id: 'scheduler_h1_id',
												value: false,
											},
										],
									},
								],
							},
							{
								xtype: 'textarea',
								width: 500,
								height: 45,
								grow: true,
								growMin: 45,
								fieldLabel: 'Comment',
								labelAlign: 'right',
								id: 'scheduler_comment',
								disabledCls: 'my-item-disabled',
								listeners: {
									// 'change': function (thisCmp, newValue, oldValue, eOpts) {
									// 	itemEditorWindowDataModify = true;
									// }
								},
							},
						],
					},
					{
						xtype: 'fieldcontainer',
						layout: {
							type: 'hbox',
							//defaultMargins: {top: 5, right: 0, bottom: 5, left: 0}
						},
						items: [
							{
								xtype: 'button',
								margin: '5 0 0 5',
								border: 1,
								style: {
									backgroundColor: '#F0F0F0',
									borderColor: '#AAAAAA',
									borderStyle: 'solid',
								},
								text: 'ok',
								//disabled:,
								width: 120,
								id: 'scheduler_save_id',
								disabledCls: 'my-item-disabled',
								handler: function () {
									const start = Ext.getCmp('scheduler_start_date').getValue();
									const end = moment(Ext.getCmp('scheduler_end_date').getValue()).add(1, 'days').toDate();
									const resourceId = Ext.getCmp('scheduler_EMP_id').getValue();

									const data = calendar.getEvents().filter((e) => e._def.resourceIds[0] === resourceId && ((e.start >= start && e.start < end) || (e.end > start && e.end < end) || (e.end > end && e.start <= start)) && e.end - end != 0 && e.start - start != 0);

									if (data.length > 0) {
										Ext.MessageBox.alert('Warning', 'Can not add overlap event');
									} else {
										SchedulerEditorWindow.myExtraParams.action && handleDelevent(SchedulerEditorWindow.myExtraParams.event, true);

										const title = `${Ext.getCmp('scheduler_sche_type_id').getDisplayValue()}<br/>${Ext.getCmp('scheduler_time_range_id').getDisplayValue()}`;
										//${getempdate(Ext.getCmp("scheduler_sche_type_id").getValue())}
										const color_index = Ext.getCmp('scheduler_sche_type_id').getValue();
										handleAddevent({
											start: start,
											end: end,
											title: title,
											resourceId: resourceId,
											schetype: Ext.getCmp('scheduler_sche_type_id').getValue(),
											timerange: Ext.getCmp('scheduler_time_range_id').getValue(),
											oncall: Ext.getCmp('scheduler_oncall_id').getValue(),
											h1day: Ext.getCmp('scheduler_h1_id').getValue(),
											comment: Ext.getCmp('scheduler_comment').getValue(),
											backgroundColor: getempdaycolor(color_index),
											textColor: getempdayTextcolor(color_index),
											borderColor: Ext.getCmp('scheduler_h1_id').getValue() ? getempdaycolor(-1) : getempdaycolor(color_index),
											classNames: Ext.getCmp('scheduler_h1_id').getValue() ? ['myscheduleBorder'] : [],
											overlap: false,
										});
									}
								},
							},
							{
								xtype: 'button',
								margin: '5 0 0 5',
								border: 1,
								style: {
									backgroundColor: '#F0F0F0',
									borderColor: '#AAAAAA',
									borderStyle: 'solid',
								},
								text: 'Delete',
								//disabled:,
								width: 120,
								id: 'scheduler_del_id',
								disabledCls: 'my-item-disabled',
								handler: function () {
									handleDelevent(SchedulerEditorWindow.myExtraParams.event);
								},
							},
						],
					},
				],
			},
		],
	},
});

//排班資料更改畫面
const SchedulerClickWindow = Ext.create('Ext.window.Window', {
	title: 'Scheduler Editor',
	//width: 600,
	resizable: false,
	layout: 'fit',
	modal: true, //Disable底視窗畫面
	closeAction: 'close', //close 或 hide
	listeners: {
		beforeclose: function (win) {},
	},
	items: {
		// Let's put an empty grid in just to illustrate fit layout
		xtype: 'panel',
		frame: true,
		flex: 1,
		items: [
			{
				//width: 600,
				xtype: 'fieldcontainer',
				layout: {
					type: 'vbox',
				},
				items: [
					{
						xtype: 'fieldset',
						//title: 'Editor',
						collapsible: false,
						border: false,
						margin: '5 5 5 5',
						items: [
							{
								//width: 500,
								xtype: 'fieldcontainer',
								layout: {
									type: 'vbox',
								},
								items: [
									{
										xtype: 'tagfield',
										width: 500,
										cellWrap: true,
										grow: true,
										growMax: 22,
										fieldLabel: '排程日期',
										labelAlign: 'right',
										store: emp_days_store,
										queryMode: 'local',
										filter: true,
										lazyRender: true,
										typeAhead: true,
										selectOnFocus: true,
										forceSelection: true,
										value: '',
										loadMask: false,
										displayField: 'days', //顯示用
										valueField: 'id', //
										id: 'scheduler_days_id',
										disabledCls: 'my-item-disabled',
									},
								],
							},
							{
								xtype: 'combo',
								//width: 250,
								fieldLabel: 'Employee',
								name: 'EMP_name',
								labelAlign: 'right',
								store: emp_store,
								queryMode: 'local',
								filter: true,
								lazyRender: true,
								typeAhead: true,
								selectOnFocus: true,
								forceSelection: true,
								value: '',
								loadMask: false,
								displayField: 'title', //顯示用
								valueField: 'id', //
								id: 'scheduler_days_EMP_id',
								disabledCls: 'my-item-disabled',
							},
							{
								xtype: 'combo',
								//width: 250,
								fieldLabel: 'Schedule Type',
								labelAlign: 'right',
								store: emp_schetype_store,
								queryMode: 'local',
								filter: true,
								lazyRender: true,
								typeAhead: true,
								selectOnFocus: true,
								forceSelection: true,
								value: '',
								loadMask: false,
								displayField: 'type', //顯示用
								valueField: 'id', //
								id: 'scheduler_days_sche_type_id',
								disabledCls: 'my-item-disabled',
								listeners: {
									change: function (thisCmp, newValue, oldValue, eOpts) {
										if (newValue === '3-0500') {
											Ext.getCmp('scheduler_days_h1_id').setValue(true);
										} else {
											Ext.getCmp('scheduler_days_h1_id').setValue(false);
										}

										if (newValue === '2-0051') {
											Ext.getCmp('scheduler_days_oncall_id').setValue(true);
										} else {
											Ext.getCmp('scheduler_days_oncall_id').setValue(false);
										}

										const chk = ['2-0050', '2-0051', '3-0500'];

										if (chk.includes(newValue)) {
											Ext.getCmp('scheduler_days_oncall_id').setDisabled(false);
										} else {
											Ext.getCmp('scheduler_days_oncall_id').setDisabled(true);
										}
										if (SchedulerClickWindow.myExtraParams) {
											SchedulerClickWindow.myExtraParams.sid === newValue ? getTimeRange(SchedulerClickWindow.myExtraParams.timerange, 'scheduler_days_sche_type_id', 'scheduler_days_time_range_id') : getTimeRange(null, 'scheduler_days_sche_type_id', 'scheduler_days_time_range_id');
										} else getTimeRange(null, 'scheduler_days_sche_type_id', 'scheduler_days_time_range_id');
									},
								},
							},
							{
								xtype: 'combo',
								//width: 250,
								fieldLabel: 'Time Range',
								labelAlign: 'right',
								store: emp_trange_store,
								queryMode: 'local',
								filter: true,
								lazyRender: true,
								typeAhead: true,
								selectOnFocus: true,
								forceSelection: true,
								value: '',
								loadMask: false,
								displayField: 'tdisplay', //顯示用
								valueField: 'id', //
								id: 'scheduler_days_time_range_id',
								disabledCls: 'my-item-disabled',
							},
							{
								xtype: 'fieldcontainer',
								fieldLabel: '當日 On Call',
								labelWidth: 80,
								labelAlign: 'right',
								layout: {
									type: 'hbox',
								},
								items: [
									{
										xtype: 'checkboxgroup',
										width: 230,
										items: [
											{
												id: 'scheduler_days_oncall_id',
												value: false,
											},
										],
									},
								],
							},
							{
								xtype: 'fieldcontainer',
								fieldLabel: '當日休息日',
								labelWidth: 80,
								labelAlign: 'right',
								layout: {
									type: 'hbox',
								},
								items: [
									{
										xtype: 'checkboxgroup',
										width: 230,
										items: [
											{
												id: 'scheduler_days_h1_id',
												value: false,
											},
										],
									},
								],
							},
							{
								xtype: 'textarea',
								width: 500,
								height: 45,
								grow: true,
								growMin: 45,
								fieldLabel: 'Comment',
								labelAlign: 'right',
								id: 'scheduler_days_comment',
								disabledCls: 'my-item-disabled',
								listeners: {
									// 'change': function (thisCmp, newValue, oldValue, eOpts) {
									// 	itemEditorWindowDataModify = true;
									// }
								},
							},
						],
					},
					{
						xtype: 'fieldcontainer',
						layout: {
							type: 'hbox',
							//defaultMargins: {top: 5, right: 0, bottom: 5, left: 0}
						},
						items: [
							{
								xtype: 'button',
								margin: '5 0 0 5',
								border: 1,
								style: {
									backgroundColor: '#F0F0F0',
									borderColor: '#AAAAAA',
									borderStyle: 'solid',
								},
								text: 'ok',
								//disabled:,
								width: 120,
								id: 'scheduler_days_save_id',
								disabledCls: 'my-item-disabled',
								handler: function () {
									const days = Ext.getCmp('scheduler_days_id').getValue();
									let adde = [];
									let isEdit = false;

									SchedulerClickWindow.myExtraParams.eventdata.map((c) => {
										if (days.includes(moment(c.start).format('YYYY-MM-DD'))) {
											isEdit = true;
											const d = {
												start: c.start,
												end: c.end,
												title: c.title,
												resourceId: c.resourceId,
												schetype: Ext.getCmp('scheduler_days_sche_type_id').getValue(),
												timerange: Ext.getCmp('scheduler_days_time_range_id').getValue(),
												oncall: Ext.getCmp('scheduler_days_oncall_id').getValue(),
												h1day: Ext.getCmp('scheduler_days_h1_id').getValue(),
												comment: Ext.getCmp('scheduler_days_comment').getValue(),
												timerangename: Ext.getCmp('scheduler_days_time_range_id').getDisplayValue(),
											};
											adde = [...adde, { ...d }];
										} else {
											//adde=[...adde,{...c}];
										}
									});
									if (isEdit) {
										SchedulerClickWindow.myExtraParams.event.remove();
										margeevent(adde);
									}
									isEdit && backupLog();
									SchedulerClickWindow.close();
								},
							},
							{
								xtype: 'button',
								margin: '5 0 0 5',
								border: 1,
								style: {
									backgroundColor: '#F0F0F0',
									borderColor: '#AAAAAA',
									borderStyle: 'solid',
								},
								text: 'Delete',
								//disabled:,
								width: 120,
								id: 'scheduler_days_del_id',
								disabledCls: 'my-item-disabled',
								handler: function () {
									const days = Ext.getCmp('scheduler_days_id').getValue();
									let adde = [];
									let isDel = false;

									SchedulerClickWindow.myExtraParams.eventdata.map((c) => {
										if (days.includes(moment(c.start).format('YYYY-MM-DD'))) {
											isDel = true;
										} else {
											const d = { timerangename: Ext.getCmp('scheduler_days_time_range_id').getDisplayValue(), ...c };
											adde = [...adde, { ...d }];
										}
									});
									if (isDel) {
										SchedulerClickWindow.myExtraParams.event.remove();
										margeevent(adde);
									}
									isDel && backupLog();
									SchedulerClickWindow.close();
								},
							},
						],
					},
				],
			},
		],
	},
});

//複製排程視窗
const SchedulerEMPWindow = Ext.create('Ext.window.Window', {
	title: '複製排程',
	//width: 600,
	resizable: false,
	layout: 'fit',
	modal: true, //Disable底視窗畫面
	closeAction: 'close', //close 或 hide
	listeners: {
		beforeclose: function (win) {},
	},
	items: {
		// Let's put an empty grid in just to illustrate fit layout
		xtype: 'panel',
		frame: true,
		flex: 1,
		items: [
			{
				xtype: 'combo',
				//width: 250,
				fieldLabel: '欲重複對象',
				name: 'EMP_name',
				labelAlign: 'right',
				store: emp_store,
				queryMode: 'local',
				filter: true,
				lazyRender: true,
				typeAhead: true,
				selectOnFocus: true,
				forceSelection: true,
				value: '',
				loadMask: false,
				displayField: 'title', //顯示用
				valueField: 'id', //
				id: 'cscheduler_EMP_id',
				disabledCls: 'my-item-disabled',
				listeners: {
					change: function (thisCmp, newValue, oldValue, eOpts) {
						const allRecords = (emp_store.getData().getSource() || emp_store.getData()).getRange();
						const data = allRecords;
						SetStoreArray(data, emp_store1);
					},
				},
			},
			{
				xtype: 'fieldcontainer',
				layout: {
					type: 'hbox',
					//defaultMargins: {top: 5, right: 0, bottom: 5, left: 0}
				},
				items: [
					{
						xtype: 'datefield',
						//width: 250,
						fieldLabel: '從開始日期',
						labelAlign: 'right',
						id: 'cscheduler_start_date',
						format: 'Y-m-d',
						dateFormat: 'Y-m-d',
						renderer: function (val, meta, record) {
							return Ext.Date.format(val, 'Y-m-d');
						},
					},
					{
						xtype: 'label',
						labelWidth: '100%',
						text: '　~　',
					},
					{
						xtype: 'datefield',
						//width: 150,
						labelWidth: '100%',
						fieldLabel: '結束日期',
						labelAlign: 'right',
						id: 'cscheduler_end_date',
						format: 'Y-m-d',
						dateFormat: 'Y-m-d',
						renderer: function (val, meta, record) {
							return Ext.Date.format(val, 'Y-m-d');
						},
					},
				],
			},
			{
				xtype: 'combo',
				//width: 250,
				fieldLabel: '目的地對象',
				name: 'dest_EMP_name',
				labelAlign: 'right',
				store: emp_store1,
				queryMode: 'local',
				filter: true,
				lazyRender: true,
				typeAhead: true,
				selectOnFocus: true,
				forceSelection: true,
				value: '',
				loadMask: false,
				displayField: 'title', //顯示用
				valueField: 'id', //
				id: 'cscheduler_EMP_id1',
				disabledCls: 'my-item-disabled',
			},
			{
				xtype: 'fieldcontainer',
				layout: {
					type: 'hbox',
					//defaultMargins: {top: 5, right: 0, bottom: 5, left: 0}
				},
				items: [
					{
						xtype: 'datefield',
						//width: 250,
						fieldLabel: '目的地展開日期',
						labelAlign: 'right',
						id: 'scheduler_start_date_1',
						format: 'Y-m-d',
						dateFormat: 'Y-m-d',
						renderer: function (val, meta, record) {
							return Ext.Date.format(val, 'Y-m-d');
						},
					},
				],
			},
			{
				xtype: 'textfield',
				//width: 500,
				fieldLabel: '重複次數',
				labelAlign: 'right',
				id: 'scheduler_cycle_times',
				disabledCls: 'my-item-disabled',
				listeners: {
					// 'change': function (thisCmp, newValue, oldValue, eOpts) {
					// 	itemEditorWindowDataModify = true;
					// }
				},
			},
			{
				xtype: 'label',
				forId: 'myFieldId',
				text: '*請留意!若重複之班別日期跨過次月者，次月班別資料將無法被儲存。',
				margin: '0 0 0 10',
			},
			{
				xtype: 'fieldcontainer',
				layout: {
					type: 'hbox',
					//defaultMargins: {top: 5, right: 0, bottom: 5, left: 0}
				},
				items: [
					{
						xtype: 'button',
						margin: '5 0 0 5',
						border: 1,
						style: {
							backgroundColor: '#F0F0F0',
							borderColor: '#AAAAAA',
							borderStyle: 'solid',
						},
						text: 'ok',
						//disabled:,
						width: 120,
						id: 'scheduler_EMP_save_id',
						disabledCls: 'my-item-disabled',
						handler: function () {
							const d1 = Ext.getCmp('cscheduler_start_date').getValue();
							const d2 = moment(Ext.getCmp('cscheduler_end_date').getValue()).add(1, 'days').toDate();
							const d3 = Ext.getCmp('scheduler_start_date_1').getValue();
							const t = Ext.getCmp('scheduler_cycle_times').getValue();
							const id = Ext.getCmp('cscheduler_EMP_id').getValue();
							const id1 = Ext.getCmp('cscheduler_EMP_id1').getValue();
							const data = calendar.getEvents().filter((c) => c.end > d1 && c.start < d2 && c._def.resourceIds[0] === id);
							const d1m = moment(d1);
							const d3m = moment(d3);
							const d = d3m.diff(d1m, 'days');
							const dg = moment(d2).diff(d1m, 'days');
							const rd1 = d3m.toDate();
							const rd2 = d3m.add(moment(d2).diff(d1m, 'days') * t, 'days').toDate();
							const removedata = calendar.getEvents().filter((c) => c.end > rd1 && c.start < rd2 && c._def.resourceIds[0] === id1);
							calendar.batchRendering(() => {
								let dd = d;
								for (let i = 1; i <= t; i++) {
									removedata.length > 0 && removedata.forEach((e) => e.remove());
									data.map((e) => {
										const st = moment.max(moment(e.start), moment(d1));
										const ed = moment.min(moment(e.end), moment(d2));
										const id1 = Ext.getCmp('cscheduler_EMP_id1').getValue();
										calendar.addEvent({
											start: st.add(dd, 'days').toDate(),
											end: ed.add(dd, 'days').toDate(),
											resourceId: id1,
											title: e.title ? e.title : '',
											schetype: e.extendedProps.schetype,
											timerange: e.extendedProps.timerange,
											oncall: e.extendedProps.oncall,
											h1day: e.extendedProps.h1day,
											comment: e.extendedProps.comment,
											backgroundColor: e.backgroundColor,
											borderColor: e.borderColor,
											textColor: e.textColor,
											classNames: e.classNames,
											overlap: e.overlap,
										});
									});
									dd += Math.abs(dg);
								}
							});
							backupLog();
							SchedulerEMPWindow.close();
						},
					},
					{
						xtype: 'button',
						margin: '5 0 0 5',
						border: 1,
						style: {
							backgroundColor: '#F0F0F0',
							borderColor: '#AAAAAA',
							borderStyle: 'solid',
						},
						text: 'Cancel',
						//disabled:,
						width: 120,
						id: 'scheduler_EMP_del_id',
						disabledCls: 'my-item-disabled',
						handler: function () {
							SchedulerEMPWindow.close();
						},
					},
				],
			},
		],
	},
});

//複製人員視窗
const SchedulerCopyWindow = Ext.create('Ext.window.Window', {
	title: '複製人員',
	//width: 600,
	resizable: false,
	layout: 'fit',
	modal: true, //Disable底視窗畫面
	closeAction: 'close', //close 或 hide
	listeners: {
		beforeclose: function (win) {},
		beforeshow: function (win) {
			emp_store1.removeAll();
		},
	},
	items: {
		// Let's put an empty grid in just to illustrate fit layout
		xtype: 'panel',
		frame: true,
		flex: 1,
		items: [
			{
				xtype: 'combo',
				width: 300,
				fieldLabel: '複製對象',
				//labelWidth: 120,
				name: 'EMP_name',
				labelAlign: 'right',
				store: emp_store,
				queryMode: 'local',
				filter: true,
				lazyRender: true,
				typeAhead: true,
				selectOnFocus: true,
				forceSelection: true,
				value: '',
				loadMask: false,
				displayField: 'title', //顯示用
				valueField: 'id', //
				id: 'copyscheduler_EMP_id',
				disabledCls: 'my-item-disabled',
				listeners: {
					change: function (thisCmp, newValue, oldValue, eOpts) {
						const allRecords = (emp_store.getData().getSource() || emp_store.getData()).getRange();
						const data = allRecords.filter((c) => c.id !== newValue);
						SetStoreArray(data, emp_store1);
					},
				},
			},
			{
				xtype: 'tagfield',
				fieldLabel: '目的地對象',
				width: 300,
				cellWrap: true,
				grow: true,
				growMax: 40,
				name: 'EMP_name1',
				labelAlign: 'right',
				store: emp_store1,
				queryMode: 'local',
				filter: true,
				lazyRender: true,
				typeAhead: true,
				selectOnFocus: true,
				forceSelection: true,
				value: '',
				loadMask: false,
				displayField: 'title', //顯示用
				valueField: 'id', //
				id: 'copyscheduler_EMP_id1',
				disabledCls: 'my-item-disabled',
			},
			{
				// },{
				//     xtype: 'combo',
				//     //width: 250,
				//     fieldLabel: '目的地對象',
				//     //labelWidth: 120,
				//     name: 'EMP_name1',
				//     labelAlign: 'right',
				//     store: emp_store1,
				//     queryMode: 'local',
				//     filter: true,
				//     lazyRender: true,
				//     typeAhead: true,
				//     selectOnFocus: true,
				//     forceSelection: true,
				//     value: '',
				//     loadMask: false,
				//     displayField: 'title', //顯示用
				//     valueField: 'id', //
				//     id: 'copyscheduler_EMP_id1',
				//     disabledCls: 'my-item-disabled',
				// }, {
				xtype: 'label',
				forId: 'myFieldId',
				text: '*請留意!此功能將統一取代目的地對象整月班別',
				margin: '0 0 0 10',
			},
			{
				xtype: 'fieldcontainer',
				layout: {
					type: 'hbox',
					//defaultMargins: {top: 5, right: 0, bottom: 5, left: 0}
				},
				items: [
					{
						xtype: 'button',
						margin: '5 0 0 5',
						border: 1,
						style: {
							backgroundColor: '#F0F0F0',
							borderColor: '#AAAAAA',
							borderStyle: 'solid',
						},
						text: 'ok',
						//disabled:,
						width: 120,
						id: 'copyscheduler_EMP_save_id',
						disabledCls: 'my-item-disabled',
						handler: function () {
							const selectId = Ext.getCmp('copyscheduler_EMP_id').getValue();
							const copyId = Ext.getCmp('copyscheduler_EMP_id1').getValue();
							const eventAll = calendar.getEvents();
							const selectdata = eventAll.filter((c) => c._def.resourceIds[0] === selectId && moment(c.start).month() === moment(calendar.view.activeStart).month() && moment(c.start).year() === moment(calendar.view.activeStart).year());

							calendar.batchRendering(() => {
								copyId.map((cid) => {
									const deldata = eventAll.filter((c) => c._def.resourceIds[0] === cid && moment(c.start).month() === moment(calendar.view.activeStart).month() && moment(c.start).year() === moment(calendar.view.activeStart).year());
									deldata.length > 0 &&
										deldata.map((e) => {
											e.remove();
										});
									selectdata.map((e) => {
										calendar.addEvent({
											start: e.start,
											end: e.end,
											resourceId: cid,
											title: e.title ? e.title : '',
											schetype: e.extendedProps.schetype,
											timerange: e.extendedProps.timerange,
											oncall: e.extendedProps.oncall,
											h1day: e.extendedProps.h1day,
											comment: e.extendedProps.comment,
											backgroundColor: e.backgroundColor,
											borderColor: e.borderColor,
											textColor: e.textColor,
											classNames: e.classNames,
											overlap: e.overlap,
										});
									});
								});
							});
							//calendar.refetchResources();
							backupLog();
							SchedulerCopyWindow.close();
						},
					},
					{
						xtype: 'button',
						margin: '5 0 0 5',
						border: 1,
						style: {
							backgroundColor: '#F0F0F0',
							borderColor: '#AAAAAA',
							borderStyle: 'solid',
						},
						text: 'Cancel',
						//disabled:,
						width: 120,
						id: 'copyscheduler_EMP_del_id',
						disabledCls: 'my-item-disabled',
						handler: function () {
							SchedulerCopyWindow.close();
						},
					},
				],
			},
		],
	},
});

//匯出PDF
const exportPDF = () => {
	var tempId = Array.from($('.myselect-EMPgroup').find(':selected'))
		.map((e) => e.value)
		.toString();
	if (emp_group_store.getById(tempId) != null) {
		calendar.render();
		const printArea = calendar.view.type === 'resourceEMPCard' ? document.querySelector('#printWrapper') : document.querySelector('.fc-scrollgrid');
		//printArea.style.transform = "rotate(90deg)";
		html2canvas(printArea, {
			width: printArea.scrollWidth + (calendar.view.type === 'resourceEMPCard' ? 20 : 2),
		}).then((canvas) => {
			//document.body.appendChild(canvas);
			//const dataURL = canvas.toDataURL();
			const pdf = new jspdf.jsPDF('landscape', 'pt', 'a4');

			const contentWidth = canvas.width;
			const contentHeight = canvas.height;

			//一頁pdf顯示html頁面生成的canvas高度;
			//const pageHeight = contentWidth / (595.28) * (841.89);

			const p1 = contentWidth / 801.89;
			const p2 = contentHeight / 555.28;

			const p3 = p1 > p2 ? p1 : p2;
			const ph = contentHeight / p3;
			const pw = contentWidth / p3;
			const pageData = canvas.toDataURL('image/jpeg', 1.0);
			pdf.setFont('SourceHanSansTW-VF', 'normal');
			pdf.text(moment().format('YYYY/MM/DD HH:mm'), 20, 20);
			if (emp_group_store.getById(tempId) != null) {
				pdf.text(emp_group_store.getById(tempId).data.group, 400, 20);
			}

			pdf.addImage(pageData, 'JPEG', (831.89 - pw) / 2, 30, pw, ph);

			pdf.save(moment(calendar.view.activeStart).format('yyyy-MM-DD') + '.pdf');
		});
	} else {
		Ext.Msg.alert('Warning', 'PDF 列印請選擇單一部門');
	}
};

// $(document).ready(function() {
//     $("body").tooltip({ selector: '[data-toggle=tooltip]' });
// });

const Myinit = () => {
	grouptmp = [];
	emptmp = [];
	datagroup = [];
	IsUpdate = true;
	eventlog = [];
	indexlog = -1;
	//defdatagroup=[];
	schedulerEMPgroupid = '';
	MyHoliday = [];
	MyRest = [];
	loadEventData = [];
	defsavedata = [];
	errmsg = null;
	toolbarevent = [];
	//companyId = "";
};

//取得當月行事曆資料
const getnoweventdata = async () => {
	fetch(
		'./Scheduler.php?action=getTeamMembers&' +
			new URLSearchParams({
				year_month: moment(calendar ? calendar.view.activeStart : new Date()).format('YYYYMM'),
			}),
		{
			method: 'GET',
			headers: new Headers({
				'Content-Type': 'application/json',
			}),
		}
	)
		.then((response) => response.json())
		.then((data) => {
			let i = 0;
			loadEventData = [];
			data.data
				.map((e) => {
					i++;
					const evt = e.SCHEDULES.map((c) => {
						return { ...c, id: e.EMPLOYEE_NO };
					});
					loadEventData = [...loadEventData, ...evt];
				})
				.sort((a, b) => (a.seq > b.seq ? 1 : a.seq === b.seq ? (a.title < b.title ? 1 : -1) : -1));
			setdefdata();
		});
};

//取得先前排程
const getCommonInit = async () => {
	fetch('./Scheduler.php?action=getCommonShift&', {
		method: 'GET',
		headers: new Headers({
			'Content-Type': 'application/json',
		}),
	})
		.then((response) => response.json())
		.then((data) => {
			toolbarevent = [];
			data.data.map((c) => {
				const d = {
					schetype: c.SCHEDULE_ID,
					timerange: c.TIME_RANGE_ID,
					timerangename: c.TIME_RANGE,
				};
				toolbarevent = [...toolbarevent, { ...d }];

				//settoolbarmsg();
			});

			settoolbarmsg();

			fetch('./Scheduler.php?action=getAnnouncement&', {
				method: 'GET',
				headers: new Headers({
					'Content-Type': 'application/json',
				}),
			})
				.then((response) => response.json())
				.then((data) => {
					const el = document.querySelector('#Mytoolbar').querySelector('.MyDraggingMsg');
					if (data) {
						data.data.length > 0 && (el.innerHTML = data.data[0].MESSAGE);
					}
				});
		});
};

//更動常用班別
const SaveCommonShift = () => {
	const csdata = toolbarevent.map((c) => {
		return {
			sch_type: c.schetype,
			sch_time: c.timerange,
		};
	});

	fetch(
		'./Scheduler.php?' +
			new URLSearchParams({
				action: 'saveCommonShift',
				// records: `[${records}]`,
			}),
		{
			method: 'POST',
			// headers: new Headers({
			// 	'Content-Type': 'application/json',
			// }),
			body: JSON.stringify(csdata),
		}
	)
		.then((response) => response.json())
		.then((data) => {
			//console.log(eventdata);
		});
};

const setdefdata = (renderevent = false) => {
	let val = [];

	loadEventData.map((e) => {
		const color_index = e.SCHEDULE_ID;
		const allRecords = (emp_schetype_store.getData().getSource() || emp_schetype_store.getData()).getRange();
		const data = allRecords.filter((c) => c.id === color_index);
		const date = moment(e.DATE);
		const d = {
			start: date.toDate(),
			end: date.add(1, 'days').toDate(),
			resourceId: e.id,
			title: `${data[0].data.type}<br/>${e.TIME_RANGE}`,
			schetype: e.SCHEDULE_ID,
			timerange: e.SCHEDULE_TIME_ID,
			oncall: e.IS_ONCALL === 'Y' ? true : false,
			h1day: e.IS_REST === 'Y' ? true : false,
			comment: e.COMMENT || '',
			backgroundColor: getempdaycolor(color_index),
			borderColor: e.IS_REST === 'Y' ? getempdaycolor(-1) : getempdaycolor(color_index),
			textColor: getempdayTextcolor(color_index),
			classNames: e.IS_REST === 'Y' ? ['myscheduleBorder'] : [],
			overlap: false,
		};
		if (val.length === 0) {
			val = [{ ...d }];
		} else {
			const t = val[val.length - 1];
			t.resourceId === d.resourceId && t.schetype === d.schetype && t.timerange === d.timerange && t.oncall === d.oncall && t.h1day === d.h1day && t.comment === d.comment && moment(t.end).format('YYYYMMDD') === moment(d.start).format('YYYYMMDD') ? (val[val.length - 1].end = d.end) : (val = [...val, { ...d }]);
		}
	});

	defsavedata = val;

	if (renderevent) {
		calendar.batchRendering(() => {
			const data = calendar.getEvents();
			data.forEach((e) => e.remove());

			val.forEach((e, index, array) => {
				calendar.addEvent(e);
			});
		});

		backupLog();
	}
};

const margeevent = async (eventdata) => {
	let val = [];

	eventdata.map((e) => {
		const color_index = e.schetype;
		const allRecords = (emp_schetype_store.getData().getSource() || emp_schetype_store.getData()).getRange();
		const data = allRecords.filter((c) => c.id === color_index);
		const date = moment(moment(e.start).format('YYYY-MM-DD'));
		const d = {
			start: date.toDate(),
			end: date.add(1, 'days').toDate(),
			resourceId: e.resourceId,
			title: `${data[0].data.type}<br/>${e.timerangename}`,
			schetype: e.schetype,
			timerange: e.timerange,
			oncall: e.oncall,
			h1day: e.h1day,
			comment: e.comment || '',
			backgroundColor: getempdaycolor(color_index),
			borderColor: e.h1day ? getempdaycolor(-1) : getempdaycolor(color_index),
			textColor: getempdayTextcolor(color_index),
			classNames: e.h1day ? ['myscheduleBorder'] : [],
			overlap: false,
		};
		if (val.length === 0) {
			val = [{ ...d }];
		} else {
			const t = val[val.length - 1];
			t.resourceId === d.resourceId && t.schetype === d.schetype && t.timerange === d.timerange && t.oncall === d.oncall && t.h1day === d.h1day && t.comment === d.comment && moment(t.end).format('YYYYMMDD') === moment(d.start).format('YYYYMMDD') ? (val[val.length - 1].end = d.end) : (val = [...val, { ...d }]);
		}
	});

	calendar.batchRendering(() => {
		val.forEach((e, index, array) => {
			calendar.addEvent(e);
		});
	});

	return;
};
const schedulerInitResource = (newValue, successCallback = null) => {
	const tmp = emptmp.filter((e) => newValue.includes(e.id));
	const unique = [...new Set(tmp.map((item) => item.group))];
	const data = emptmp.filter((e) => unique.includes(e.group));

	setScheduleEMPGroup(newValue);
	SetStoreArray(data, emp_store);
	calendar.getResources().map((e) => e.remove());
	const edata = calendar.getEvents();

	const dataupdate = data.map((e) => {
		const ev = edata.filter((c) => c._def.resourceIds[0] === e.id);
		let evtotal = 0;
		let wh = 8;
		ev.map((x) => {
			const d1 = moment(x.start);
			const d2 = moment(x.end);
			const evdays = d2.diff(d1, 'days');
			if (x.extendedProps) {
				const whindex = emp_schetype_store.find('id', x.extendedProps.schetype);
				if (whindex > -1) {
					wh = emp_schetype_store.getAt(whindex).data.wh;
					evtotal += wh * evdays;
				}
			}
		});

		return { ...e, act: evtotal === 0 ? '' : evtotal };
	});
	successCallback ? successCallback(dataupdate) : dataupdate.map((e) => calendar.addResource(e));
	IsUpdate = !IsUpdate;
};

//取得班別
const getScheType = () => {
	fetch(
		'./Scheduler.php?action=getScheduleType&' +
			new URLSearchParams({
				company_id: companyId,
			}),
		{
			method: 'GET',
			headers: new Headers({
				'Content-Type': 'application/json',
			}),
		}
	)
		.then((response) => response.json())
		.then((data) => {
			const stdata = data.data.map((e) => {
				return { id: e.SCHEDULE_ID, type: e.SCHEDULE_NAME, wh: e.WORK_HOURS || 8, name: e.ALIAS_NAME, color: e.SCHEDULE_COLOR };
			});
			//successCallback(items);
			SetStoreArray(stdata, emp_schetype_store).then((c) => {
				ReaderToolBar();

				setdefdata(true);
			});
		});
};

const backupLog = () => {
	$('[data-toggle="tooltip"]').tooltip('dispose');
	$('.tooltip').remove();
	const eventdata = calendar.getEvents().map((e) => {
		return {
			start: e.start,
			end: e.end,
			resourceId: e._def.resourceIds[0],
			title: e.title ? e.title : '',
			schetype: e.extendedProps.schetype,
			timerange: e.extendedProps.timerange,
			oncall: e.extendedProps.oncall,
			h1day: e.extendedProps.h1day,
			comment: e.extendedProps.comment,
			backgroundColor: e.backgroundColor,
			borderColor: e.borderColor,
			textColor: e.textColor,
			classNames: e.classNames,
			overlap: e.overlap,
		};
	});

	indexlog > -1 && (eventlog = eventlog.filter((c, i) => i <= indexlog))[0];
	eventlog.length > 0 ? (eventlog = [...eventlog, ...[eventdata]]) : (eventlog = [eventdata]);
	indexlog = -1;

	$('[data-toggle="tooltip"]').tooltip();
	// setTimeout(( () => {
	//     // $('[data-toggle="tooltip"]').tooltip('dispose');
	//      //$('[data-toggle="tooltip"]').tooltip();

	// }), 1200);

	// $("body").tooltip({
	//     selector : '[data-toggle=tooltip]'
	// });
	eventlog.length > 1 && (document.querySelector('#Mytoolbar').querySelector('.mybtn-lock').disabled = true);
};

//取得班別時間
const getTimeRange = (value, id1 = 'scheduler_sche_type_id', id2 = 'scheduler_time_range_id') => {
	fetch(
		'./Scheduler.php?action=getTimeRange&' +
			new URLSearchParams({
				schedule_id: Ext.getCmp(id1).getValue(),
			}),
		{
			method: 'GET',
			headers: new Headers({
				'Content-Type': 'application/json',
			}),
		}
	)
		.then((response) => response.json())
		.then((data) => {
			const stdata = data.data.map((e) => {
				return { id: e.TIME_RANGE_ID, tdisplay: `${e.S_TIME}~${e.HR_E_TIME}`, def: e.IS_DEFAULT };
			});
			//successCallback(items);
			value ? SetStoreArray(stdata, emp_trange_store, id2, value) : SetStoreArray(stdata, emp_trange_store, id2);
		});
};

const getHoliday = () => {
	fetch(
		'./Scheduler.php?action=getHoliday&' +
			new URLSearchParams({
				year_month: moment(calendar.view.activeStart).format('YYYYMM'),
				company_id: companyId,
			}),
		{
			method: 'GET',
			headers: new Headers({
				'Content-Type': 'application/json',
			}),
		}
	)
		.then((response) => response.json())
		.then((data) => {
			MyHoliday = data.data;
			calendar && calendar.changeView('resourceDayGridDayMonyhly');
			setTimeout(() => {
				$('[data-toggle="tooltip"]').tooltip();
			}, 1200);

			// setTimeout(( () => {
			//     settoolbarhdmsg();
			// }), 500);
		});
};

const getRestday = () => {
	fetch(
		'./Scheduler.php?action=getRestday&' +
			new URLSearchParams({
				year_month: moment(calendar.view.activeStart).format('YYYYMM'),
				company_id: companyId,
			}),
		{
			method: 'GET',
			headers: new Headers({
				'Content-Type': 'application/json',
			}),
		}
	)
		.then((response) => response.json())
		.then((data) => {
			MyRest = data.data;
			calendar && calendar.changeView('resourceDayGridDayMonyhly');
			setTimeout(() => {
				$('[data-toggle="tooltip"]').tooltip();
			}, 1200);
		});
};

const settoolbarmsg = () => {
	const el = document.querySelector('#Mytoolbar').querySelector('.MyToolBarTitle');
	// const allRecords = (emp_schetype_store.getData().getSource() || emp_schetype_store.getData()).getRange();
	// const data =allRecords.map(c=>{
	//     return {...c}
	// });
	const html = `
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class='MyDraggingEvent'>
            ${ReaderDraggingIcon(toolbarevent)}
            </div>
            <div class='MyDraggingMsg text-left'>
            </div>
        </div>
    </div>
    `;
	// const html = `
	//     <div class="card">
	//         <div class="card-body pt-0 pb-0">
	//             <提醒>
	//             <br/>
	//             若同仁因班別調整，調移休息日至週一~週五。因影響差勤紀錄&加班費率，請務必正確排配休息日。
	//             <br/>
	//             1.請派配調移日當日為「休息日」。
	//             <br/>
	//             2.請定義同仁當月所有的「休息日」，至少需派定八個 「休息日」 。
	//             <br/>
	//             3.凡當日未指定班別&休息者之日期，系統將自動視為常日班+工作日。
	//             <br/>
	//             <div class="Myhdahy"></div>
	//         </div>
	//     </div>
	// `
	el.innerHTML = html;

	const Draggable = FullCalendar.Draggable;
	const containerEl = document.querySelector('.MyDraggingEvent');

	new Draggable(containerEl, {
		itemSelector: '.MyDraggingEventData',
		eventData: (eventEl) => {
			const schetype = eventEl.dataset.schetype || '';
			const timerange = eventEl.dataset.timerange || '';
			const oncall = schetype === '2-0051' ? true : false;
			const h1day = schetype === '3-0500' ? true : false;
			const color_index = schetype;
			const allRecords = (emp_schetype_store.getData().getSource() || emp_schetype_store.getData()).getRange();
			const data = allRecords.filter((c) => c.id === color_index);
			return {
				duration: { days: 1 },
				title: eventEl.dataset.originalTitle || '',
				schetype: schetype,
				timerange: timerange,
				oncall: oncall,
				h1day: h1day,
				backgroundColor: getempdaycolor(color_index),
				borderColor: h1day ? getempdaycolor(-1) : getempdaycolor(color_index),
				textColor: getempdayTextcolor(color_index),
				classNames: h1day ? ['myscheduleBorder'] : [],
				overlap: false,
				comment: '',
			};
		},
	});

	handleDraggingevent();
};

const settoolbarhdmsg = () => {
	const el = document.querySelector('#Mytoolbar').querySelector('.Myhdahy');
	const hd = MyHoliday.map((e) => moment(calendar.view.activeStart).format('MM') + '/' + e);
	const html = `
        ${
			hd.length > 0
				? `<div class="bg-yellow text-dark">本月${hd}為國定假日，不論班別凡有出勤時數皆可申報OT，加班未滿8小時數以8小時計
        </div>`
				: ''
		}
    `;
	el.innerHTML = html;
};

const setdef = async (e, successCallback = null) => {
	// const db = await idb.openDB('hmesdb', 1, {
	//     upgrade(db, oldVersion, newVersion, transaction) {
	//         db.createObjectStore('schedule');
	//     },
	// });

	// const tx = db.transaction('schedule', 'readwrite');
	// const store = tx.objectStore('schedule');
	// const val = (await store.get('eventdata')) || [];
	// const EMP = (await store.get('resource')) || [];
	// //await store.put(val + 1, 'counter');
	// await tx.done;

	let tmp = defdatagroup;

	if (tmp.length === 0 && datagroup.length === 1) tmp = datagroup;

	const dg = [...new Map(tmp.map((item) => [item['group'], item])).values()];
	grouptmp = dg.map((e) => e.id);

	if (tmp.length > 0) {
		const temp = emptmp.filter((e) => e.id === tmp[0].id);
		companyId = temp.length > 0 ? temp[0].company_id : '';
	}

	await getScheType();

	await schedulerInitResource(grouptmp, successCallback);

	if (Array.from($('.myselect-EMPgroup').find(':selected')).map((e) => e.value).length > 0) {
		$('.myselect-EMPgroup').selectpicker('val', grouptmp);
	}

	//getTimeRange();
	//emptmp=EMP;
};

// const savedb = async (key, val) => {
//     const db = await idb.openDB('hmesdb', 1, {
//         upgrade(db, oldVersion, newVersion, transaction) {
//             db.createObjectStore('schedule');
//         },
//     });

//     const tx = db.transaction('schedule', 'readwrite');
//     const store = tx.objectStore('schedule');
//     //const val = (await store.get('eventdata')) || [];
//     await store.put(val, key);
//     await tx.done;

// }

/* const savedata= (event) =>{
    const data = calendar.getEvents();
    const eventdata= data.map(e => {
    //   const rs =emptmp.filter((item, index, array)=>{
    // 	return (item.id === e._def.resourceIds[0]) 
    //   });

    const d = {        
        start: e.startStr,
        end: e.endStr,
        resourceId: e._def.resourceIds[0],
        title: e.title,
    }
    return d;
    });

    browserIEHandler || savedb("eventdata",eventdata);
    const tmp=emptmp.filter(e=>grouptmp.includes(e.id))
    const unique = [...new Set(tmp.map(item => item.group))]; 
    const EMPdata=emptmp.filter(e=>unique.includes(e.group));
    browserIEHandler ||  savedb("resource",EMPdata);


} */

// const loaderCSV  = (e) => {
//     //修正 IE11 無法使用 readAsBinaryString
//     if (FileReader.prototype.readAsBinaryString === undefined) {
//         FileReader.prototype.readAsBinaryString = function (fileData) {
//             var binary = "";
//             var pt = this;
//             var reader = new FileReader();
//             reader.onload = function (e) {
//                 var bytes = new Uint8Array(reader.result);
//                 var length = bytes.byteLength;
//                 for (var i = 0; i < length; i++) {
//                     binary += String.fromCharCode(bytes[i]);
//                 }
//                 //pt.result  - readonly so assign content to another property
//                 pt.content = binary;
//                 pt.onload(); // thanks to @Denis comment

//             }
//             reader.readAsArrayBuffer(fileData);
//         }
//     }
//     if (e){
//       const file = e;
//       const reader = new FileReader();
//       reader.onload = (evt) => {
//         /* Parse data */
//           const bstr = !evt ?reader.content:evt.target.result;
//           const wb = XLSX.read(bstr, { type: 'binary', cellDates: true, dateNF: 'yyyy-mm-dd'});
//           /* Get first worksheet */
//           const wsname = wb.SheetNames[0];
//           const ws = wb.Sheets[wsname];
//           /* Convert array of arrays */
//           const data = XLSX.utils.sheet_to_csv(ws, { header: 1, dateNF: 'yyyy-mm-dd' });
//           processData(data);
//       };
//       reader.readAsBinaryString(file);

//     }

// }

// const processData = dataString => {

//     const data = calendar.getEvents();

//     //const dataStringLines = dataString.split(/\r\n|\n/);
//     const dataStringLines = dataString.split(/\n(?![^"]*"(?:(?:[^"]*"){2})*[^"]*$)/)
//     const headers = dataStringLines[0].split(/,(?![^"]*"(?:(?:[^"]*"){2})*[^"]*$)/);

//     const list = [];
//     for (let i = 1; i < dataStringLines.length; i++) {
//     const row = dataStringLines[i].split(/,(?![^"]*"(?:(?:[^"]*"){2})*[^"]*$)/);
//     if (headers && row.length === headers.length) {
//         const obj = {};
//         for (let j = 0; j < headers.length; j++) {
//         let d = row[j];
//         if (d.length > 0) {
//             if (d[0] === '"')
//             d = d.substring(1, d.length - 1);
//             if (d[d.length - 1] === '"')
//             d = d.substring(d.length - 2, 1);
//         }
//         if (headers[j]) {
//             obj[headers[j]] = d;
//         }
//         }

//         // remove the blank rows
//         if (Object.values(obj).filter(x => x).length > 0) {
//         list.push(obj);
//         }
//     }
//     }
//     // prepare columns list from headers
//     // const columns = headers.map(c => ({
//     //   name: c,
//     //   selector: c,
//     // }));

//     data.forEach((e) =>e.remove());
//     list.forEach((e) =>calendar.addEvent(e));

// }

/* const exportCSV  = () => {
    //savedata();

    const data = calendar.getEvents();
    const eventdata= data.map(e => {
        const d = {        
        start: e.startStr,
        end: e.endStr,
        resourceId: e._def.resourceIds[0],
        title: e.title,
        machine:emptmp.filter(c=>e._def.resourceIds[0]===c.id)[0].title,
        }           
        return d;
    });
    const sheet = XLSX.utils.json_to_sheet(eventdata);
    const workBook= XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workBook, sheet,strhead);
    //sheet['!protect'] = {password:'hmes!'};
    XLSX.writeFile(workBook, strhead+'.xlsx', {bookType:"xlsx", type: 'buffer'});


} */

const SetStoreArray = async (items, store, id, value) => {
	store.getProxy().setData(items);
	store.load();
	const v = store.first() && store.first().data.id;
	const allRecords = (store.getData().getSource() || store.getData()).getRange();
	const tmp = allRecords.filter((c) => c.data.def === 'Y');
	const val = tmp.length > 0 ? tmp[0].id : v;
	if (id) {
		Ext.getCmp(id).reset();
		Ext.getCmp(id).setValue(value || val);
	}
	//EMPalltmp=items;

	//console.log(store);
};

//刪除行程
const handleDelevent = (event, isbackup) => {
	event.remove();
	SchedulerEditorWindow.close();
	isbackup || backupLog();
};

const MycollapseHide = () => {
	const containerEl = document.querySelector('.MyDraggingEvent');
	containerEl.querySelectorAll('.MydisplayBtn').forEach((v) => {
		const att = v.dataset.collapseid;
		$(att).collapse('hide');
	});
};

//常用班別事件
const handleDraggingevent = () => {
	const containerEl = document.querySelector('.MyDraggingEvent');
	document.removeEventListener('click', MycollapseHide, false); //del old event
	document.addEventListener('click', MycollapseHide, false);

	const promise1 = new Promise((resolve, reject) => {
		containerEl.querySelectorAll('.MyDraggingEventDataBtn').forEach((v) => {
			v.addEventListener('click', (e) => {
				$('[data-toggle="tooltip"]').tooltip('dispose');
				const el = e.currentTarget.closest('.MyDraggingEventData');
				const schetype = el.dataset.schetype || '';
				toolbarevent = toolbarevent.filter((c) => c.schetype !== schetype);
				const html = ReaderDraggingIcon(toolbarevent);
				const ele = e.currentTarget.closest('.MyDraggingEvent');
				ele.innerHTML = html;
				handleDraggingevent();
				SaveCommonShift();
			});
		});

		containerEl.querySelectorAll('.MydisplayBtn').forEach((v) => {
			v.addEventListener('click', (e) => {
				const att = e.currentTarget.dataset.collapseid;
				toolbarmenulist(e.currentTarget.dataset.schetype, att, e.currentTarget.dataset.timerange, 1);
				$(att).collapse('toggle');
			});
		});

		resolve(true);
	});
	promise1.then((value) => {
		$('[data-collapse="collapse"]').collapse();
	});
};

const MyiconHide = () => {
	const containerEl = document.querySelector('.MyinfoModalIcon');
	containerEl.querySelectorAll('.Myfav-icon').forEach((v) => {
		const att = v.dataset.collapseid;
		$(att).collapse('hide');
	});
};

//資訊欄常用班別事件
const handleIconevent = () => {
	const containerEl = document.querySelector('.MyinfoModalIcon');
	document.removeEventListener('click', MyiconHide, false); //del old event
	document.addEventListener('click', MyiconHide, false);

	const promise1 = new Promise((resolve, reject) => {
		containerEl.querySelectorAll('.Myfav-icon').forEach((v) => {
			v.addEventListener('click', (e) => {
				const el = e.currentTarget;
				const att = el.dataset.collapseid;
				if (att) {
					const ele = el.querySelector('.fas');
					if (ele) {
						const icon = '<i class="far fa-star"></i>';
						el.innerHTML = icon;
						toolbarevent = toolbarevent.filter((c) => c.schetype !== el.dataset.schetype);
						const html = ReaderDraggingIcon(toolbarevent);
						const tele = document.querySelector('.MyDraggingEvent');
						tele.innerHTML = html;
						handleDraggingevent();
						SaveCommonShift();
					} else {
						toolbarmenulist(el.dataset.schetype, att, '', 2, el);
						$(att).collapse('toggle');
					}
				}
			});
		});

		resolve(true);
	});
	promise1.then((value) => {
		$('[data-collapse="collapse"]').collapse();
	});
};

const handleAddevent = (event) => {
	calendar.addEvent(event);
	SchedulerEditorWindow.close();
	//console.log(calendar.getEvents());

	// const tmp = toolbarevent.filter(c=>c.schetype===event.schetype );
	// if(tmp.length ===0){
	//     const temp = event.title.split("<br/>");
	//     const d ={
	//         schetype: event.schetype ,
	//         timerange: event.timerange,
	//         timerangename:temp[1],
	//     };
	//     toolbarevent = [...toolbarevent,{...d}];
	//     const html =ReaderDraggingIcon(toolbarevent);
	//     document.querySelector("#Mytoolbar").querySelector(".MyDraggingEvent").innerHTML=html;

	//     handleDraggingevent();
	//     SaveCommonShift();
	// }

	backupLog();
};

//星期
const getweekdat = (e, d, p) => {
	const plus = p ? 'text-light' : '';
	switch (e) {
		case '0':
			return `
                <div class="text-danger ${plus}">${d || `日`}</div>
            `;
		// return `
		// <div class="text-danger">${d||`日`}</div>
		// `;
		case '1':
			return `
                <div class=" ${plus}">${d || `一`}</div>
            `;
		case '2':
			return `
                <div class=" ${plus}">${d || `二`}</div>
            `;
		case '3':
			return `
                <div class=" ${plus}">${d || `三`}</div>
            `;
		case '4':
			return `
                <div class=" ${plus}">${d || `四`}</div>
            `;
		case '5':
			return `
                <div class=" ${plus}">${d || `五`}</div>
            `;
		case '6':
			return `
                <div class="text-danger ${plus}">${d || `六`}</div>
            `;
		default:
			return '';
	}
};

//班別底色
const getempdaycolor = (index) => {
	//const tmp = calendarSetting.filter(c=>c.id===index);
	const allRecords = (emp_schetype_store.getData().getSource() || emp_schetype_store.getData()).getRange();
	const tmp = allRecords.filter((c) => c.id === index);
	return tmp.length > 0 ? tmp[0].data.color : '#d50000';
};

const getGray = (Hex) => {
	const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(Hex);
	const r = parseInt(result[1], 16);
	const g = parseInt(result[2], 16);
	const b = parseInt(result[3], 16);
	const gray = (r * 299 + g * 587 + b * 114) / 1000;
	return gray > 148 ? '#424242' : '#fff';
};

//班別字色
const getempdayTextcolor = (index) => {
	const allRecords = (emp_schetype_store.getData().getSource() || emp_schetype_store.getData()).getRange();
	const data = allRecords.filter((c) => c.id === index);
	return index ? getGray(data[0].data.color) : '#fff';
};

//快捷鍵
document.addEventListener('keyup', (e) => {
	// ctrl+z
	if (e.ctrlKey && e.key === 'z' && ac) {
		if (indexlog !== 0) {
			indexlog > 0 ? indexlog-- : (indexlog = eventlog.length - 2);

			if (calendar && indexlog >= 0) {
				$('[data-toggle="tooltip"]').tooltip('dispose');

				calendar.batchRendering(() => {
					// remove all events
					calendar.getEvents().forEach((event) => event.remove());

					// add your new events
					const newEvents = eventlog[indexlog];
					newEvents.forEach((event) => calendar.addEvent(event));
				});
				//$('[data-toggle="tooltip"]').tooltip('dispose');
				$('[data-toggle="tooltip"]').tooltip();
			}
		}
	}
	// ctrl+y
	if (e.ctrlKey && e.key === 'y' && ac) {
		if (indexlog !== eventlog.length - 1 && indexlog !== -1) {
			indexlog++;
			if (calendar && indexlog >= 0) {
				$('[data-toggle="tooltip"]').tooltip('dispose');

				calendar.batchRendering(() => {
					// remove all events
					calendar.getEvents().forEach((event) => event.remove());

					// add your new events
					const newEvents = eventlog[indexlog];
					newEvents.forEach((event) => calendar.addEvent(event));
				});
				//$('[data-toggle="tooltip"]').tooltip('dispose');
				$('[data-toggle="tooltip"]').tooltip();
			}
		}
	}
});

const setScheduleEMPGroup = (e) => {
	schedulerEMPgroupid = e;
};

const setSchedulerForm = (e) => {
	Ext.getCmp('scheduler_start_date').setValue(e.start);
	Ext.getCmp('scheduler_end_date').setValue(moment(e.end).add(-1, 'days').toDate());
	Ext.getCmp('scheduler_EMP_id').setValue(e.resource ? e.resource._resource.id : e._def.resourceIds[0]);
	if (e.extendedProps) {
		Ext.getCmp('scheduler_sche_type_id').setValue(e.extendedProps.schetype);
		Ext.getCmp('scheduler_time_range_id').setValue(e.extendedProps.timerange);
		Ext.getCmp('scheduler_oncall_id').setValue(e.extendedProps.oncall);
		Ext.getCmp('scheduler_h1_id').setValue(e.extendedProps.h1day);
		Ext.getCmp('scheduler_comment').setValue(e.extendedProps.comment);
	} else {
		Ext.getCmp('scheduler_sche_type_id').setValue('');
		Ext.getCmp('scheduler_time_range_id').setValue('');
		Ext.getCmp('scheduler_oncall_id').setValue('');
		Ext.getCmp('scheduler_h1_id').setValue('');
		Ext.getCmp('scheduler_comment').setValue('');
	}
};

const setSchedulerDaysForm = (e) => {
	Ext.getCmp('scheduler_days_EMP_id').setValue(e.resource ? e.resource._resource.id : e._def.resourceIds[0]);
	if (e.extendedProps) {
		Ext.getCmp('scheduler_days_sche_type_id').setValue(e.extendedProps.schetype);
		Ext.getCmp('scheduler_days_time_range_id').setValue(e.extendedProps.timerange);
		Ext.getCmp('scheduler_days_oncall_id').setValue(e.extendedProps.oncall);
		Ext.getCmp('scheduler_days_h1_id').setValue(e.extendedProps.h1day);
		Ext.getCmp('scheduler_days_comment').setValue(e.extendedProps.comment);
	} else {
		Ext.getCmp('scheduler_days_sche_type_id').setValue('');
		Ext.getCmp('scheduler_days_time_range_id').setValue('');
		Ext.getCmp('scheduler_days_oncall_id').setValue('');
		Ext.getCmp('scheduler_days_h1_id').setValue('');
		Ext.getCmp('scheduler_days_comment').setValue('');
	}
};

const setSchedulerEMPForm = (e) => {
	Ext.getCmp('cscheduler_start_date').setValue(e.start);
	Ext.getCmp('cscheduler_end_date').setValue(moment(e.end).add(-1, 'days').toDate());
	Ext.getCmp('cscheduler_EMP_id').setValue(e.resource ? e.resource._resource.id : e._def.resourceIds[0]);
	Ext.getCmp('scheduler_start_date_1').setValue(e.end);
	Ext.getCmp('scheduler_cycle_times').setValue(1);
};

//資訊欄視窗
const MyinfoMsg = () => {
	const allRecords = (emp_schetype_store.getData().getSource() || emp_schetype_store.getData()).getRange();
	const data = allRecords.map((c) => {
		return { ...c };
	});
	const message = `
    <div class="modal fade" id="MyinfoModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header d-flex justify-content-between">
                <div><h5 class="modal-title mt-0" id="exampleModalLongTitle">資訊欄</h5></div>
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title mt-0">常用班別</h5>
                        <p class="card-text">
                        ● 設定方式：請點選☆指定班別，可設定上下班時段，於主頁面作為快捷班別使用
                        <br/>
                        ● 取消設定：點選★指定班別
                        <br/>
                        ● 更改上下班時段：點選★指定班別，重新選擇上下班時段
                        </p>
                    </div>
                </div>
                <div>
                    <button type="button" class="close Myclosebtn" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                </div>
                <div class="modal-body">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-md-auto text-center MyinfoModalIcon">
                        ${ReaderToolIcon(data)}
                        </div>
                    </div>
                    <div class="row mt-2">
                        <div class="col">
                            <table class="table table-striped">
                                <thead>
                                    <tr>
                                    <th scope="col">快捷鍵</th>
                                    <th scope="col">說明</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <td scope="row">【ctrl + z】</td>
                                    <td>回復上一步驟</td>
                                    </tr>
                                    <tr>
                                    <td scope="row">【ctrl + y】</td>
                                    <td>取消回復上一步驟</td>
                                    </tr>
                                    <tr scope="row">
                                    <td>滑鼠拖曳指定<u>班別</u>→至其它日期</td>
                                    <td>該班別將移動→至目標日期</td>
                                    </tr>
                                    <td scope="row">【ctrl + 滑鼠拖曳指定<u>班別</u>】→至其它日期</td>
                                    <td>該班別將被複製→至目標日期</td>
                                    </tr>
                                    <tr>
                                    <td scope="row">工號及員工列，可以滑鼠上下拖曳</td>
                                    <td>可依需求，滑鼠上下拖曳，調整排列順序，系統將於 Save 時同時儲存</td>
                                    </tr>
                                    <tr scope="row">
                                    <td>【ctrl +複製對象：工號或員工列】→滑鼠上下拖曳→ 【目的地對象：工號或員工列下方】</td>
                                    <td>可直接複製該員工當月班別，至另一人</td>
                                    </tr>
                                    <tr>
                                    <td scope="row">點選<u>班別</u>的左右邊界，可以滑鼠左右拖曳</td>
                                    <td>可調整該班別的起迄日期
                                    <br/>
                                    ←提早開始
                                    <br/>
                                    →往後展延
                                    </td>
                                    </tr>
                                    <tr scope="row">
                                    <td>滑鼠滑動至<u>班別</u>(右上<i class="fas fa-caret-up fa-rotate-180 text-danger"></i>者)</td>
                                    <td>可查看REMARK說明</td>
                                    </tr>
                                </tbody>                        
                            </table>
                        </div>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>`;
	const el = document.querySelector('#MyInfoDilog');
	el.innerHTML = message;

	$('#MyinfoModal').modal('show');
	handleIconevent();
};

//載入提示框
const RenderInnerContent = (innerProps) => {
	const allRecords = (emp_schetype_store.getData().getSource() || emp_schetype_store.getData()).getRange();
	const data = allRecords.filter((c) => c.id === innerProps.event.extendedProps.schetype);
	return `
        <div className='fc-event-main-frame includer tooltip-inner' data-html="true" draggable="true" data-toggle="tooltip" title="${innerProps.event.extendedProps.comment ? innerProps.event.title + '<br/>' + innerProps.event.extendedProps.comment : innerProps.event.title}">
            ${innerProps.event.extendedProps.comment ? `<span class="badge count-notif"><i class="text-danger fas fa-square fa-rotate-45 fa-lg"></i></span>` : ``}		
            ${innerProps.timeText ? `<div className='fc-event-time'>${innerProps.timeText}</div>` : ``}
            <div className='fc-event-title-container'>
                <div class ="MyTitle" className='fc-event-title fc-sticky} '>   
                    ${innerProps.event.extendedProps.oncall ? `<i class="fas fa-phone-square ml-1 mr-1"></i>` : ``}          
                    ${data[0].data.name || '&nbsp;'}
                </div>	
            </div>			
        </div>       
    `;
};

//載入工具列
const ReaderToolBar = () => {
	const allRecords = (emp_schetype_store.getData().getSource() || emp_schetype_store.getData()).getRange();
	const data = allRecords.map((c) => {
		return { ...c };
	});
	// const data =allRecords.map(c=>{
	//     return {...c,color : getempdaycolor(c.id)}
	// });
	SetStoreArray(data, emp_store1);
	const html = `
    <div class="container-fluid">
        <div class="row">
            <div class="col-2">
                <div class="row">
                    <div class="col">
                        <p class="h5 mytext-title textoverflow">
                            ${strhead}
                        </p>
                    </div>
                </div>
                <div class="row">
                    <div class="col">
                        <div class="btn-group mr-2" role="group" aria-label="First group">
                            <button type="button" class="btn btn-secondary btn-sm mybtn-today"><i class="fas fa-calendar-day"></i></button>
                            <button type="button" class="btn btn-secondary btn-sm mybtn-prev"><i class="fas fa-chevron-left"></i></button>
                            <button type="button" class="btn btn-secondary btn-sm mybtn-next"><i class="fas fa-chevron-right"></i></button>
                            <button type="button" class="btn btn-secondary btn-sm mybtn-selectdate"><i class="fas fa-calendar-alt"></i></button>
                        </div>
                    </div>
                </div>
                <div class="row">
                </div>
            </div>
            <div class="col-4 px-0 titleoverflow">
                <div class="MyToolBarTitle" data-role="drag-drop-container"></div>
            </div>
            <div class="col-6 textoverflow text-right align-self-center pl-5 pr-0">
                <div class="float-right">
                    <div class="col" >
                        <button type="button" class="btn btn-dark btn-circle btn-sm mybtn-info"><i class="fas fa-info"></i></button>
                        <div class="btn-group mr-2" role="group" aria-label="First group">
                            <select class="selectpicker myselect-EMPgroup" multiple data-live-search="true" data-size="3">
                                ${datagroup.map(
									(e) => `
                                    <option class="small" value="${e.id}">${e.group}</option>
                                `
								)}
                            </select>
                        </div>
						<div class="btn-group mr-2" role="group" aria-label="First group">
									<button type="button" class="btn btn-success btn-sm mybtn-pdf"><i class="fas fa-file-pdf mr-2"></i>PDF</button>
								</div>
                        <div class="btn-group mr-2" role="group" aria-label="First group">
                            <button type="button" class="btn btn-success btn-sm mybtn-save"><i class="fas fa-save mr-2"></i>Save</button>
                        </div>
                        <div class="btn-group mr-2" role="group" aria-label="First group">
                        <button type="button" class="btn btn-success btn-sm mybtn-repeat"><i class="fas fa-recycle mr-2"></i>複製排程</button>
                        </div>
                        <div class="btn-group mr-2" role="group" aria-label="First group">
                            <button type="button" class="btn btn-success btn-sm mybtn-copy"><i class="fas fa-copy mr-2"></i>複製人員</button>
                        </div>
                        <div class="btn-group mr-2" role="group" aria-label="First group">
                        <button type="button" class="btn btn-success btn-sm mybtn-lock"><i class="fas fa-lock-open mr-2"></i>Lock All</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    `;
	//工具列按鈕點擊事件
	const el = document.querySelector('#Mytoolbar');
	if (el == null) {
		return;
	}
	el.innerHTML = html;

	//行事曆時間控制項
	el.querySelector('.mybtn-today').addEventListener('click', (e) => {
		Myinit();
		calendar.today();
		//settitle();
		$('.mybtn-selectdate').datepicker('setDate', calendar.view.activeStart);
		calendar && calendar.refetchResources();
	});
	el.querySelector('.mybtn-prev').addEventListener('click', (e) => {
		Myinit();
		calendar.prev();
		//settitle();
		$('.mybtn-selectdate').datepicker('setDate', calendar.view.activeStart);
		calendar && calendar.refetchResources();
	});
	el.querySelector('.mybtn-next').addEventListener('click', (e) => {
		Myinit();
		calendar.next();
		//settitle();
		$('.mybtn-selectdate').datepicker('setDate', calendar.view.activeStart);
		calendar && calendar.refetchResources();
	});
	el.querySelector('.mybtn-selectdate').addEventListener(
		'click',
		((e) => {
			$('.mybtn-selectdate')
				.datepicker({
					format: 'mm-yy',
					minViewMode: 1,
				})
				.on('changeMonth', (e) => {
					Myinit();
					$('.mybtn-selectdate').datepicker('hide');
					calendar.gotoDate(e.date);
					//settitle();
					calendar && calendar.refetchResources();
				});
		})(el.querySelector('.mybtn-selectdate'))
	);

	$('.myselect-EMPgroup').selectpicker({
		style: 'btn-default btn-sm btn-outline-secondary',
	});

	// $('.myselect-EMPgroup').on('hidden.bs.select', function (e, clickedIndex, isSelected, previousValue) {
	// 	let newgroup =Array.from($(".myselect-EMPgroup").find(':selected')).map(e=>e.value);
	// 	grouptmp.toString() === newgroup.toString() || schedulerInitResource(newgroup);	grouptmp=newgroup;
	//   });
	
	//部門組別下拉選單
	el.querySelector('.myselect-EMPgroup').addEventListener('change', (e) => {
		const obj = el.querySelector('.myselect-EMPgroup').getElementsByTagName('option');
		el.querySelector('.mybtn-lock').disabled = false;
		el.querySelector('.mybtn-lock').classList.remove('btn-secondary');
		el.querySelector('.mybtn-lock').classList.add('btn-success');
		el.querySelector('.mybtn-lock').innerHTML = `<i class="fas fa-lock-open mr-2"></i>Lock All`;
		if (obj.length > 0) {
			const newgroup = Array.from($('.myselect-EMPgroup').find(':selected')).map((e) => e.value);
			const tmp = emptmp.filter((e) => newgroup.includes(e.id));
			companyId = tmp.length > 0 ? tmp[0].company_id : '';

			Array.from(obj).map((c) => {
				const tmp = emptmp.filter((e) => e.id === c.value);
				c.disabled = tmp[0].company_id !== companyId && companyId && true;
			});
			$('.myselect-EMPgroup').selectpicker('refresh');
			calendar.refetchResources();
			settitle();
		} else {
			companyId = null;
			calendar.refetchResources();
			settitle();
		}
	});

	el.querySelector('.myselect-EMPgroup').addEventListener('click', (e) => {
		if (Array.from($('.myselect-EMPgroup').find(':selected')).map((e) => e.value).length > 0) {
			const obj = el.querySelector('.myselect-EMPgroup').getElementsByTagName('option');
			if (obj.length > 0) {
				Array.from(obj).map((c) => {
					const tmp = emptmp.filter((e) => e.id === c.value);
					c.disabled = tmp[0].company_id !== companyId && companyId && true;
				});
				$('.myselect-EMPgroup').selectpicker('refresh');
			}
		}
	});
	//Save按鈕
	el.querySelector('.mybtn-save').addEventListener('click', (e) => {
		myMask.show();

		const data = calendar.getEvents();
		let eventdata = [];
		let seqdata = [];
		let saveemp = [];

		const st = moment(calendar.view.activeStart).format('YYYY-MM-01');
		const ed = moment(calendar.view.activeStart).add(1, 'M').add(-1, 'd').format('YYYY-MM-DD');
		const edday = moment(calendar.view.activeStart).add(1, 'M').format('YYYY-MM-DD');

		const newgroup = Array.from($('.myselect-EMPgroup').find(':selected')).map((e) => e.value);
		const tmp = emptmp.filter((e) => newgroup.includes(e.id));
		const unique = [...new Set(tmp.map((item) => item.group))];
		const empdata = emptmp.filter((e) => unique.includes(e.group));

		empdata.map((x) => {
			const tmp1 = data
				.filter((c) => c._def.resourceIds[0] === x.id)
				.sort((a, b) => (new Date(Math.max(new Date(moment(st)), a.start)) > new Date(Math.max(new Date(moment(st)), b.start)) ? 1 : -1))
				.map((e) => {
					return {
						start: new Date(Math.max(new Date(moment(st)), e.start)),
						end: new Date(Math.min(new Date(moment(edday)), e.end)),
						resourceId: e._def.resourceIds[0],
						title: e.title ? e.title : '',
						schetype: e.extendedProps.schetype,
						timerange: e.extendedProps.timerange,
						oncall: e.extendedProps.oncall,
						h1day: e.extendedProps.h1day,
						comment: e.extendedProps.comment,
					};
				});
			const tmp2 = defsavedata
				.filter((c) => c.resourceId === x.id)
				.sort((a, b) => (a.start > b.start ? 1 : -1))
				.map((e) => {
					return {
						start: e.start,
						end: e.end,
						resourceId: e.resourceId,
						title: e.title ? e.title : '',
						schetype: e.schetype,
						timerange: e.timerange,
						oncall: e.oncall,
						h1day: e.h1day,
						comment: e.comment,
					};
				});

			JSON.stringify(tmp1) === JSON.stringify(tmp2) || saveemp.push(x.id);
		});

		data.map((e) => {
			if (saveemp.includes(e._def.resourceIds[0])) {
				const start = moment(e.startStr);
				const end = moment(e.endStr);
				const dif = end.diff(start, 'days');
				for (i = 0; i < dif; i++) {
					const d = {
						employee_no: e._def.resourceIds[0],
						employee_username: empdata.filter((c) => e._def.resourceIds[0] === c.id)[0].username,
						team_id: empdata.filter((c) => e._def.resourceIds[0] === c.id)[0].teamId,
						schedule_id: e.extendedProps.schetype,
						schedule_date: i === 0 ? start.format('YYYY-MM-DD') : start.add(1, 'days').format('YYYY-MM-DD'),
						time_range_id: e.extendedProps.timerange,
						is_oncall: e.extendedProps.oncall,
						is_rest: e.extendedProps.h1day,
						comment: e.extendedProps.comment,
					};
					eventdata = [...eventdata, { ...d }];
				}
			}
		});

		empdata.map((x) => {
			if (saveemp.includes(x.id)) {
				const tmp = eventdata.filter((c) => c.employee_no === x.id);
				const d = {
					employee_no: x.id,
					employee_username: x.username,
					team_id: x.teamId,
					schedule_id: null,
					schedule_date: moment(calendar.view.activeStart).format('YYYY-MM-DD'),
					time_range_id: null,
					is_oncall: null,
					is_rest: null,
					comment: null,
				};
				tmp.length === 0 && (eventdata = [...eventdata, { ...d }]);
			}
		});

		const outdata = data.filter((c) => moment(c.start).format('YYYY-MM-DD') < st || moment(c.end).format('YYYY-MM-DD') > edday);

		const callBackFunc = () => {
			seqdata = empdata.map((e) => {
				return { employee_no: e.id, order_by: e.index };
			});

			const sdata = eventdata.filter((c) => c.schedule_date >= st && c.schedule_date <= ed);
			if (sdata.length > 0) {
				fetch(//排班結果
					'./Scheduler.php?' +
						new URLSearchParams({
							action: 'saveSchedule',
							company_id: companyId,
							// records: `[${records}]`,
						}),
					{
						method: 'POST',
						// headers: new Headers({
						// 	'Content-Type': 'application/json',
						// }),
						body: JSON.stringify(sdata),
					}
				)
					.then((response) => response.json())
					.then((data) => {
						//console.log(eventdata);

						// if(data.success === false){
						//     emp_group_store.removeAll();

						//     // data.data.map(c=>{
						//     //     const d= {
						//     //         EMPLOYEE_NO:c.EMPLOYEE_NO,
						//     //         MESSAGES:c.MESSAGES
						//     //     }
						//     //     emp_error_store.add(d);

						//     // })
						//     SetStoreArray(data.failed_data,emp_error_store);
						//     emp_error_window.show();
						// }
						// else if(data.success === true){
						//     let stroe_data =[];
						//     if ( data.failed_data &&  data.success_data){
						//         if(data.failed_data.length>0){
						//             const d = data.success_data.map(e=>{
						//                     return {EMPLOYEE_NO:e.EMPLOYEE_NO,MESSAGE:""};
						//             });
						//             stroe_data = [...d,...data.failed_data];
						//             SetStoreArray(stroe_data,emp_error_store);
						//             emp_error_window.show();
						//         }
						//     }
						//     if(stroe_data.length === 0){
						//         Ext.MessageBox.alert('Success', 'Save success');
						//         el.querySelector(".mybtn-lock").disabled =false;
						//     }
						// }
						let stroe_data = [];
						if (data.failed_data || data.success_data) {
							// if(data.failed_data.length>0){
							//     stroe_data = [...data.failed_data];
							// }
							const d1 = data.success_data.map((e) => {
								return { EMPLOYEE_NO: e.EMPLOYEE_NO, MESSAGES: 'save success', EMPLOYEE_NAME: e.EMPLOYEE_NAME };
							});

							const d2 = data.failed_data.map((e) => {
								return { EMPLOYEE_NO: e.EMPLOYEE_NO, MESSAGES: e.MESSAGES.replaceAll('\r\n', '<br/>'), EMPLOYEE_NAME: e.EMPLOYEE_NAME };
							});
							stroe_data = [...d2, ...d1];
							SetStoreArray(stroe_data, emp_error_store);
						}
						if (data.failed_data.length === 0) {
							//Ext.MessageBox.alert('Success', 'Save success');
							el.querySelector('.mybtn-lock').disabled = false;
							el.querySelector('.mybtn-lock').classList.remove('btn-secondary');
							el.querySelector('.mybtn-lock').classList.add('btn-success');
							el.querySelector('.mybtn-lock').innerHTML = `<i class="fas fa-lock-open mr-2"></i>Lock All`;
						}
						getnoweventdata().then((c) => {
							emp_error_window.show();
							myMask.destroy();
						});
					});
			} else {
				myMask.destroy();
			}
			fetch(
				'./Scheduler.php?' +
					new URLSearchParams({
						action: 'saveTeamMemberSequence',
						// records: `[${records}]`,
					}),
				{
					method: 'POST',
					// headers: new Headers({
					// 	'Content-Type': 'application/json',
					// }),
					body: JSON.stringify(seqdata),
				}
			)
				.then((response) => response.json())
				.then((data) => {
					//console.log(eventdata);
				});
		};

		outdata.length > 0 ? Ext.MessageBox.alert('Warning', '非當月資料不會儲存', callBackFunc) : callBackFunc();
	});
	//資訊欄按鈕
	el.querySelector('.mybtn-info').addEventListener('click', (e) => {
		MyinfoMsg();
	});
	//複製排程按鈕
	el.querySelector('.mybtn-repeat').addEventListener('click', (e) => {
		Ext.getCmp('cscheduler_start_date').setValue('');
		Ext.getCmp('cscheduler_end_date').setValue('');
		Ext.getCmp('cscheduler_EMP_id').setValue('');
		Ext.getCmp('scheduler_start_date_1').setValue('');
		Ext.getCmp('scheduler_cycle_times').setValue(1);
		SchedulerEMPWindow.show();
	});
	//複製人員按鈕
	el.querySelector('.mybtn-copy').addEventListener('click', (e) => {
		Ext.getCmp('copyscheduler_EMP_id').setValue('');
		Ext.getCmp('copyscheduler_EMP_id1').setValue('');
		SchedulerCopyWindow.show();
	});
	//Lock All按鈕
	el.querySelector('.mybtn-lock').addEventListener('click', (e) => {
		Ext.MessageBox.show({
			title: 'Caution',
			msg: '請留意!此功能將鎖定此畫面所有班別資訊，<br/>後續異動或刪除班別，將無法直接於本畫面執行，<br/>請確認是否繼續?',
			buttons: Ext.Msg.OKCANCEL,
			icon: Ext.Msg.WARNING, //Ext.Msg.INFO |  Ext.Msg.ERROR | Ext.Msg.QUESTION
			fn: (btn) => {
				if (btn == 'ok') {
					callBackFunc();
				}
			},
		});

		const callBackFunc = () => {
			if (ac) {
				el.querySelector('.mybtn-lock').classList.remove('btn-success');
				el.querySelector('.mybtn-lock').classList.add('btn-secondary');
				el.querySelector('.mybtn-lock').innerHTML = `<i class="fas fa-lock mr-2"></i>Lock All`;
			} else {
				el.querySelector('.mybtn-lock').classList.remove('btn-secondary');
				el.querySelector('.mybtn-lock').classList.add('btn-success');
				el.querySelector('.mybtn-lock').innerHTML = `<i class="fas fa-lock-open mr-2"></i>Lock All`;
			}
			ac = !ac;
			calendar.setOption('selectable', ac);
			calendar.setOption('editable', ac);
			calendar.setOption('droppable', ac);
			calendar.setOption('dropAccept', ac ? '*' : 'Mynowork');
			el.querySelector('.mybtn-copy').disabled = !ac;
			el.querySelector('.mybtn-repeat').disabled = !ac;
			// el.querySelector(".mybtn-save").disabled = !ac;
			el.querySelector('.mybtn-lock').disabled = !ac;

			const newgroup = Array.from($('.myselect-EMPgroup').find(':selected')).map((e) => e.value);
			const tmp = emptmp.filter((e) => newgroup.includes(e.id));
			const unique = [...new Set(tmp.map((item) => item.group))];
			const empdata = emptmp.filter((e) => unique.includes(e.group));
			const seqdata = empdata.map((e) => e.id);

			fetch(
				'./Scheduler.php?' +
					new URLSearchParams({
						action: 'lockAll',
						year_month: moment(calendar ? calendar.view.activeStart : new Date()).format('YYYYMM'),
					}),
				{
					method: 'POST',
					// headers: new Headers({
					// 	'Content-Type': 'application/json',
					// }),
					body: JSON.stringify(seqdata),
				}
			)
				.then((response) => response.json())
				.then((data) => {
					if (data.success === true) {
						Ext.MessageBox.alert('Success', 'Lock success');
					}
					//console.log(eventdata);
				});

			//$('[data-toggle="tooltip"]').tooltip();
		};
	});

	// toolbarevent.length===0 &&
	getCommonInit();

	//settoolbarmsg();
	// el.querySelector(".mybtn-layout1").addEventListener('click',  e =>{
	//     calendar.changeView('resourceDayGridDayMonyhly');
	//     el.querySelector(".btn-group").hidden=false;
	//     el.querySelector(".mybtn-layout1").classList.remove('btn-secondary');
	//     el.querySelector(".mybtn-layout1").classList.add('btn-success');
	//     //el.querySelector(".mybtn-layout2").classList.remove('btn-success');
	//     //el.querySelector(".mybtn-layout2").classList.add('btn-secondary');
	// });

	/* el.querySelector(".mybtn-layout2").addEventListener('click',  e =>{
        calendar.changeView('resourceEMPCard');
        el.querySelector(".btn-group").hidden=true;
        el.querySelector(".mybtn-layout2").classList.remove('btn-secondary');
        el.querySelector(".mybtn-layout2").classList.add('btn-success');
        el.querySelector(".mybtn-layout1").classList.remove('btn-success');
        el.querySelector(".mybtn-layout1").classList.add('btn-secondary');
    }); */
	
	//PDF按鈕
	el.querySelector('.mybtn-pdf').addEventListener('click', (e) => {
		//savedata();
		exportPDF();
	});
	/*
    el.querySelector(".mybtn-upload").addEventListener('click',  e =>{
        SchedulerUploadWindow.show();
    });

    el.querySelector(".mybtn-download").addEventListener('click',  e =>{
        //exportCSV();
    });
*/

	const MysortUI = $('#Mycalendar div.fc-timeline.fc-view > table > tbody > tr > td:nth-child(1) > div > div > table > tbody');
	let oldary = [];
	let ctrlKey = false;
	let selectId = '';
	let copyId = '';
	MysortUI.sortable({
		start: (event, ui) => {
			ctrlKey = event.ctrlKey;
			selectId = ui.item[0].cells[0].dataset.resourceId;
			oldary = [];
			let index = 1;
			MysortUI.find('tr').each((i, el) => {
				const eid = $(el).find('td')[0].dataset.resourceId;
				const tmp = emptmp.filter((c) => c.id === eid);
				if (tmp.length > 0) {
					const data = [{ ...tmp[0], index: index }];
					oldary = [...oldary, ...data];
					index++;
				}
			});
		},
		stop: (event, ui) => {
			$('[data-toggle="tooltip"]').tooltip('dispose');
			if (ctrlKey && ac) {
				MysortUI.find('tr').each((i, el) => {
					const eid = $(el).find('td')[0].dataset.resourceId;

					if (eid === selectId) return false;

					copyId = eid;
				});
				const eventAll = calendar.getEvents();
				const selectdata = eventAll.filter((c) => c._def.resourceIds[0] === selectId && moment(c.start).month() === moment(calendar.view.activeStart).month() && moment(c.start).year() === moment(calendar.view.activeStart).year());
				const deldata = eventAll.filter((c) => c._def.resourceIds[0] === copyId && moment(c.start).month() === moment(calendar.view.activeStart).month() && moment(c.start).year() === moment(calendar.view.activeStart).year());
				if (copyId) {
					calendar.batchRendering(() => {
						deldata.length > 0 &&
							deldata.map((e) => {
								e.remove();
							});
						selectdata.map((e) => {
							calendar.addEvent({
								start: e.start,
								end: e.end,
								resourceId: copyId,
								title: e.title ? e.title : '',
								schetype: e.extendedProps.schetype,
								timerange: e.extendedProps.timerange,
								oncall: e.extendedProps.oncall,
								h1day: e.extendedProps.h1day,
								comment: e.extendedProps.comment,
								backgroundColor: e.backgroundColor,
								borderColor: e.borderColor,
								textColor: e.textColor,
								classNames: e.classNames,
								overlap: e.overlap,
							});
						});
					});
					backupLog();
				}
			} else {
				let rtmp = [];
				MysortUI.find('tr').each((i, el) => {
					const eid = $(el).find('td')[0].dataset.resourceId;
					const tmp = emptmp.filter((c) => c.id === eid);
					const tmpindex = oldary.filter((c) => c.index === i + 1);
					if (tmp.length > 0 && tmpindex.length > -0) {
						const data = [{ ...tmp[0], seq: tmpindex[0].seq, index: i + 1 }];
						rtmp = [...rtmp, ...data];
					}
				});
				const emptmpdata = emptmp.map((c) => {
					const d = rtmp.filter((x) => x.id === c.id);
					return d.length > 0 ? d[0] : c;
				});
				emptmp = emptmpdata.sort((a, b) => (a.index > b.index ? 1 : a.index === b.index ? (a.title > b.title ? 1 : -1) : -1));
			}

			IsUpdate = false;
			ctrlKey = false;
			selectId = '';
			copyId = '';
			calendar.refetchResources();

			$('[data-toggle="tooltip"]').tooltip();
		},
	}).disableSelection();

	let tmp = defdatagroup;

	if (tmp.length === 0 && datagroup.length === 1) tmp = datagroup;

	const dg = [...new Map(tmp.map((item) => [item['group'], item])).values()];
	grouptmp = dg.map((e) => e.id);

	Array.from($('.myselect-EMPgroup').find(':selected')).map((e) => e.value) && $('.myselect-EMPgroup').selectpicker('val', grouptmp);

	// if(!ac){
	//     el.querySelector(".mybtn-lock").classList.remove('btn-success');
	//     el.querySelector(".mybtn-lock").classList.add('btn-secondary');
	//     el.querySelector(".mybtn-lock").innerHTML=`<i class="fas fa-lock mr-2"></i>Lock`;
	// }
	// else{
	//     el.querySelector(".mybtn-lock").classList.remove('btn-secondary');
	//     el.querySelector(".mybtn-lock").classList.add('btn-success');
	//     el.querySelector(".mybtn-lock").innerHTML=`<i class="fas fa-lock-open mr-2"></i>UnLock`;
	// }

	// el.querySelector(".mybtn-copy").disabled = !ac;
	// el.querySelector(".mybtn-repeat").disabled = !ac;
	// el.querySelector(".mybtn-save").disabled = !ac;
	ac = true;
	calendar.setOption('selectable', ac);
	calendar.setOption('editable', ac);
	calendar.setOption('droppable', ac);
	calendar.setOption('dropAccept', ac ? '*' : 'Mynowork');
};

//常用班別時間
const toolbarmenulist = (schetype, index, timerange, btntype, el) => {
	fetch(
		'./Scheduler.php?action=getTimeRange&' +
			new URLSearchParams({
				schedule_id: schetype,
			}),
		{
			method: 'GET',
			headers: new Headers({
				'Content-Type': 'application/json',
			}),
		}
	)
		.then((response) => response.json())
		.then((data) => {
			const stdata = data.data.map((e) => {
				return { id: e.TIME_RANGE_ID, tdisplay: `${e.S_TIME}~${e.HR_E_TIME}`, def: e.IS_DEFAULT };
			});
			//successCallback(items);
			let html = `<div class="list-group">`;
			const temp = toolbarevent.filter((c) => c.schetype === schetype);
			const tg = temp.length > 0 ? temp[0].timerange : '';
			const tmp = stdata
				.map((e) => {
					const active = e.id === tg ? 'active' : '';
					return `
                    <button type="button" class="btn-sm Myfav-icon list-group-item list-group-item-action py-1 ${active}" data-timerange="${e.id}"  data-timerangename="${e.tdisplay}"> 
                        ${e.tdisplay}
                    </button>     
                `;
				})
				.join('');
			html += `${tmp}</div>`;

			document.querySelector(index).innerHTML = html;

			if (btntype === 1) {
				document
					.querySelector(index)
					.querySelectorAll('.list-group-item')
					.forEach((v) => {
						v.addEventListener('click', (e) => {
							document
								.querySelector(index)
								.querySelectorAll('.list-group-item')
								.forEach((x) => {
									if (x.dataset.timerange === e.currentTarget.dataset.timerange) {
										e.currentTarget.classList.add('active');
										const el = e.currentTarget.closest('.Mymenu-center').previousElementSibling;
										const sptext = el.dataset.originalTitle.split('<br/>');
										const title = sptext
											.map((e, index) => {
												return index === 1 ? v.dataset.timerangename : e;
											})
											.join('<br/>');
										el.dataset.originalTitle = title;
									} else {
										x.classList.remove('active');
									}
								});
							toolbarevent.find((c) => {
								if (c.schetype === schetype) {
									c.timerange = v.dataset.timerange;
									c.timerangename = v.dataset.timerangename;
								}
							});
							SaveCommonShift();
						});
					});
			} else if (btntype === 2) {
				document
					.querySelector(index)
					.querySelectorAll('.list-group-item')
					.forEach((v) => {
						v.addEventListener('click', (e) => {
							$('[data-toggle="tooltip"]').tooltip('dispose');
							const d = {
								schetype: schetype,
								timerange: v.dataset.timerange,
								timerangename: v.dataset.timerangename,
							};
							toolbarevent = [...toolbarevent, { ...d }];

							const html = ReaderDraggingIcon(toolbarevent);
							document.querySelector('#Mytoolbar').querySelector('.MyDraggingEvent').innerHTML = html;

							handleDraggingevent();

							const icon = '<i class="fas fa-star"></i>';
							el.innerHTML = icon;
							SaveCommonShift();
							$('[data-toggle="tooltip"]').tooltip();
						});
					});
			}
		});
};

//載入常用班別
const ReaderDraggingIcon = (event) => {
	let l = event.length % 3;
	let html = '';
	const tmp = event
		.map((e, index) => {
			const color_index = e.schetype;
			const allRecords = (emp_schetype_store.getData().getSource() || emp_schetype_store.getData()).getRange();
			const data = allRecords.filter((c) => c.id === color_index);
			return `<div class="badge MypositionRelative w-25 mr-1 px-1 py-1"><div class="MyDraggingEventData text-center" data-toggle="tooltip" data-schetype="${e.schetype}"
        data-html="true" title="${data[0].data.type + '<br/>' + e.timerangename}" data-timerange="${e.timerange}">
        <div style="background-color:${getempdaycolor(color_index)};color:${getempdayTextcolor(color_index)}" class="py-1 pr-1 badge-pill"">
        <a class="MydisplayBtn" data-collapse="collapse" href="#" data-collapseid="#MyEventCollapse${index}" data-timerange="${e.timerange}" data-schetype="${e.schetype}" role="button" aria-expanded="false" aria-controls="MyEventCollapse${index}">
        ${data[0].data.name}
        </a>
        <button type="button" style="color:${getempdayTextcolor(color_index)}" class="close icon-small MyDraggingEventDataBtn" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
        </button></div></div>
            <div class="Mymenu-center collapse external-toogle-content-section rounded" id="MyEventCollapse${index}">
            </div>
        </div>`;
		})
		.join('');
	html = tmp;
	l === 0 && (l = 3);
	for (j = l; j <= 3; j++) {
		html += `<span class="badge badge-pill bg-white mt-1 mr-1 w-25">&nbsp</span>`;
	}

	return html;
};

//載入資訊欄班別
const ReaderToolIcon = (data) => {
	let i = 1;
	let html = '';
	const tmp = data
		.map((e, index) => {
			i === 3 && (i = 1);
			const color = getGray(e.data.color);
			i++;
			const active = toolbarevent.filter((c) => c.schetype === e.id);
			return `
        <span style="background-color:${e.data.color};color:${color}" class="MypositionRelative badge badge-pill my-1 pt-1 mr-4 w-25">
        <button type="button" style="background-color:${e.data.color};color:${color}" class="float-left btn btn-link Myfav-icon px-0 py-0" data-collapse="collapse" data-collapseid="#MyEventfavorite${index}" data-schetype="${e.id}">
            ${active.length > 0 ? '<i class="fas fa-star"></i>' : '<i class="far fa-star"></i>'}
        </button>
        ${e.data.name}
        <div class="Mymenu-center collapse external-toogle-content-section rounded" id="MyEventfavorite${index}">
        </div>
        </span>`;
		})
		.join('');

	for (j = i; j <= 3; j++) {
		html = tmp + `<span class="badge badge-pill bg-white mt-1 mr-4 w-25">&nbsp</span>`;
	}

	return html;
};

//Jan 2023
const settitle = () => {
	strhead = new Intl.DateTimeFormat('en-US', {
		year: 'numeric',
		month: 'short',
	}).format(calendar.view.activeStart);

	const el = document.querySelector('#Mytoolbar').querySelector('.mytext-title');
	el && (el.innerText = strhead);
	getHoliday();
	getRestday();
};

//載入行事曆
const ReaderSchedule = () => {
	const calendarEl = document.getElementById('Mycalendar');//使用 FullCalendar 將 div轉成行事曆
	calendar = new FullCalendar.Calendar(calendarEl, {
		schedulerLicenseKey: 'CC-Attribution-NonCommercial-NoDerivatives',
		resourceOrder: 'index,title',
		contentHeight: 'auto',
		height: '50%',
		stickyHeaderDates: true,
		//resourceAreaHeaderContent: "Employee",
		nowIndicator: true,//標記目前時間
		editable: true,//是否修改行事曆的事件
		forceEventDuration: true,
		droppable: true,//可以拖動其他元素到行事曆
		navLinks: true,//讓日期可以被點擊
		eventOrder: ['start', 'duration', 'allDay', 'title'],//事件排序
		eventOrderStrict: true,//停用事件排序
		selectable: true,
		events: [],//可直接拖放到行事曆中的預設活動
		eventsSet: (event) => {//初始化或更動後的行為
			// IsUpdate=false;
			// calendar.refetchResources();
			// $('[data-toggle="tooltip"]').tooltip();
		},
		select: (selectionInfo) => {
			const d1 = selectionInfo.start;
			const d2 = selectionInfo.end;
			const id = selectionInfo.resource ? selectionInfo.resource._resource.id : selectionInfo._def.resourceIds[0];
			const data = calendar.getEvents().filter((c) => c.end > d1 && c.start < d2 && c._def.resourceIds[0] === id);

			if (data.length === 0) {
				setSchedulerForm(selectionInfo);
				SchedulerEditorWindow.myExtraParams = { action: 0, event: [] };
				Ext.getCmp('scheduler_del_id').setVisible(false);
				SchedulerEditorWindow.show();
				//SchedulerEMPWindow.show();
				//SchedulerEditorWindow.setLoading(true);
			} else {
				setSchedulerEMPForm(selectionInfo);
				SchedulerEMPWindow.show();
			}
		},
		eventClick: (eventClickInfo) => {
			// const rect = eventClickInfo.jsEvent.currentTarget.getBoundingClientRect();
			// let fcCellStartTime;
			// const el = eventClickInfo.jsEvent.currentTarget;
			// const clickedElement = document.elementFromPoint(eventClickInfo.jsEvent.pageX - window.pageXOffset,rect.top  - window.pageYOffset-1);
			// // Cells with text will have data-time attribute in parent div
			// if ((clickedElement.tagName) !== 'TH') {
			//     fcCellStartTime = clickedElement.parentNode.getAttribute("data-date");
			// } else {// otherwise it is a blank hour cell and it will have data-time attrib
			//     fcCellStartTime = clickedElement.getAttribute("data-date");
			// }
			// const selectedStartTime = moment(fcCellStartTime);
			// console.log(selectedStartTime);

			const e = eventClickInfo.event;

			let daysary = [];
			let defary = [];
			let eventdata = [];
			const start = moment(e.startStr);
			const end = moment(e.endStr);
			const dif = end.diff(start, 'days');
			for (i = 0; i < dif; i++) {
				const val = i === 0 ? start.format('YYYY-MM-DD') : start.add(1, 'days').format('YYYY-MM-DD');
				const d = {
					id: val,
					days: moment(val).format('MM-DD'),
				};
				const data = {
					start: new Date(val),
					end: new Date(val),
					resourceId: e._def.resourceIds[0],
					title: e.title ? e.title : '',
					schetype: e.extendedProps.schetype,
					timerange: e.extendedProps.timerange,
					oncall: e.extendedProps.oncall,
					h1day: e.extendedProps.h1day,
					comment: e.extendedProps.comment,
				};
				daysary = [...daysary, { ...d }];
				defary.push(d.id);
				eventdata = [...eventdata, { ...data }];
			}

			SetStoreArray(daysary, emp_days_store, 'scheduler_days_id', defary);

			if (ac) {
				SchedulerClickWindow.myExtraParams = { action: 1, event: eventClickInfo.event, timerange: eventClickInfo.event.extendedProps.timerange, sid: eventClickInfo.event.extendedProps.schetype, eventdata: eventdata };
				Ext.getCmp('scheduler_days_del_id').setVisible(true);
				setSchedulerDaysForm(eventClickInfo.event);
				SchedulerClickWindow.show();
				//SchedulerEditorWindow.setLoading(true);
			}

			// if(ac) {

			//     SchedulerEMPWindow.myExtraParams = { action:1, event: eventClickInfo.event ,timerange: eventClickInfo.event.extendedProps.timerange,sid:eventClickInfo.event.extendedProps.schetype  };
			//     Ext.getCmp("scheduler_del_id").setVisible(true);
			//     setSchedulerForm(eventClickInfo.event);
			//     SchedulerEMPWindow.show();
			//     //SchedulerEditorWindow.setLoading(true);
			// }
		},
		eventOverlap: false,
		eventDragStart: (e) => {},
		eventDragBeforeStop: (e) => {
			//拖到 外層移除 event
			if (ac) {
				let x = e.jsEvent.clientX;
				let y = e.jsEvent.clientY;

				let element = document.elementFromPoint(x, y);
				let actionDivElement = element && element.closest('.fc-scroller-harness .fc-timeline-body ');

				if (element && !actionDivElement) {
					e.event.remove();
					backupLog();
					//e.jsEvent.preventDefault();
				}
			}
		},
		eventDragStop: (e) => {
			//拖到 toolbar 新增 icon
			// let x = e.jsEvent.clientX;
			// let y = e.jsEvent.clientY;
			// let element = document.elementFromPoint(x, y);
			// let actionDivElement = element.closest('.MyToolBarTitle');
			// if (element && actionDivElement) {
			//     $('[data-toggle="tooltip"]').tooltip('dispose');
			//     const tmp =toolbarevent.filter(x=>x.schetype ===e.event.extendedProps.schetype);
			//     if(tmp.length>0){
			//         toolbarevent.find(c=>{
			//             if(c.schetype === e.event.extendedProps.schetype){
			//                 const ele = e.el.querySelector('[classname ^="fc-event-main-frame"]');
			//                 const tit = ele.dataset.originalTitle.split("<br/>");
			//                 c.timerange = e.event.extendedProps.timerange;
			//                 c.timerangename = tit[1];
			//                 SaveCommonShift();
			//             }
			//         });
			//     }
			//     else{
			//         const ele = e.el.querySelector('[classname ^="fc-event-main-frame"]');
			//         const tit = ele.dataset.originalTitle.split("<br/>");
			//         const d = {
			//             schetype: e.event.extendedProps.schetype ,
			//             timerange: e.event.extendedProps.timerange,
			//             timerangename:tit[1],
			//         };
			//         toolbarevent =[...toolbarevent,{...d}];
			//         SaveCommonShift();
			//     }
			//     const html =ReaderDraggingIcon(toolbarevent);
			//     document.querySelector("#Mytoolbar").querySelector(".MyDraggingEvent").innerHTML=html;
			//     handleDraggingevent();
			//     $('[data-toggle="tooltip"]').tooltip();
			// }
		},
		eventResize: (eventResizeInfo) => {
			//('.tooltip').remove();
			//$('[data-toggle="tooltip"]').tooltip('dispose');
			//$('[data-toggle="tooltip"]').tooltip();
			backupLog();
		},
		drop: (info) => {
			setTimeout(() => {
				backupLog();
			}, 500);
		},
		eventDrop: (info) => {
			$('[data-toggle="tooltip"]').tooltip('dispose');
			if (hotkey.ctrlKey && ac) {
				const e = info.oldEvent;
				const eNew = info.event;
				(e.start >= eNew.end || e.end <= eNew.start || e._def.resourceIds[0] !== eNew._def.resourceIds[0]) &&
					calendar.addEvent({
						start: e.start,
						end: e.end,
						resourceId: e._def.resourceIds[0],
						title: e.title ? e.title : '',
						schetype: e.extendedProps.schetype,
						timerange: e.extendedProps.timerange,
						oncall: e.extendedProps.oncall,
						h1day: e.extendedProps.h1day,
						comment: e.extendedProps.comment,
						backgroundColor: e.backgroundColor,
						borderColor: e.borderColor,
						textColor: e.textColor,
						classNames: e.classNames,
						overlap: e.overlap,
					});
				hotkey = null;
			}
			backupLog();

			//$('[data-toggle="tooltip"]').tooltip();
		},
		initialView: 'resourceDayGridDayMonyhly',
		views: {
			resourceDayGridDayMonyhly: {
				type: 'resourceTimeline',
				slotDuration: '24:00:00',
				duration: { month: 1 },
				resourceAreaWidth: '15%',
				slotLabelFormat: ['DD', 'd'],
				slotLabelContent: (arg) => {
					const p = MyHoliday.includes(moment(arg.date).format('DD'));
					let html = '';
					html = arg.level === 0 ? getweekdat(moment(arg.date).format('d'), arg.text, p) : getweekdat(arg.text, null, p);
					return {
						html: html,
					};
				},
				slotLabelClassNames: (arg) => {
					let css = '';
					if (MyHoliday.includes(moment(arg.date).format('DD'))) {
						css = arg.level === 1 ? 'holiday-bg ' : 'holiday-bg0';
					}
					if (MyRest.includes(moment(arg.date).format('DD'))) {
						css = 'text-danger';
					}

					return css;
				},
				eventContent: (arg) => {
					return { html: RenderInnerContent(arg) };
				},
				eventAdd: (addInfo) => {
					//$('[data-toggle="tooltip"]').tooltip('dispose');
					//$('[data-toggle="tooltip"]').tooltip();
				},
			},
		},
		// headerToolbar:{
		// 	start: 'title', // will normally be on the left. if RTL, will be on the right
		// 	center: '',
		// 	end: 'today prev,next MySetEMPGroup MySchedulePanel MyCNCPanel MyPDF MyUpload,MyDownload' // will normally be on the right. if RTL, will be on the left
		// },
		headerToolbar: false,
		customButtons: {
			MySchedulePanel: {
				text: '班表',
				click: () => {
					const el = calendarEl.querySelector('.fc-next-button');
					calendar.changeView('resourceDayGridDayMonyhly');
					calendarEl.querySelector('.fc-today-button').hidden = false;
					calendarEl.querySelector('.fc-prev-button').hidden = false;
					calendarEl.querySelector('.fc-next-button').hidden = false;
				},
			},
			/* MyCNCPanel: {
                text: '機況表',
                click: ()=>  {
                    calendar.changeView('resourceEMPCard');
                    calendarEl.querySelector(".fc-today-button").hidden=true;
                    calendarEl.querySelector(".fc-prev-button").hidden=true;
                    calendarEl.querySelector(".fc-next-button").hidden=true;

                }
            }, */
			/* MyPDF: {
                text: 'PDF',
                click: ()=>  {
                    //savedata();
                    //exportPDF();
                }
            }, */
			/* MyUpload: {
                icon: 'fas fa-cloud-upload-alt fa-lg',
                click: ()=>  {
                    SchedulerUploadWindow.show();
                }
            },
            MyDownload: {
                icon: 'fas fa-cloud-download-alt fa-lg',
                click: ()=> {
                    //exportCSV();
                }
            }, */
		},
		resourceAreaColumns: [
			{
				headerContent: '工號',
				field: 'id',
				width: '50%',
			},
			{
				headerContent: '員工',
				field: 'title',
				width: '125%',
			},
			// {
			//     headerContent:'本月應排',
			//     field:'fcst',
			//     width:'75%',
			// },
			// {
			//     headerContent:'本月已排',
			//     field:'act',
			//     width:'75%',
			// }
		],
		resources: (fetchInfo, successCallback, failureCallback) => {
			if (emptmp.length === 0) {
				fetch(//載入部門所有成員
					'./Scheduler.php?action=getTeamMembers&' +
						new URLSearchParams({
							year_month: moment(calendar ? calendar.view.activeStart : new Date()).format('YYYYMM'),
						}),
					{
						method: 'GET',
						headers: new Headers({
							'Content-Type': 'application/json',
						}),
					}
				)
					.then((response) => response.json())
					.then((data) => {
						let i = 0;
						const emps = data.data
							.map((e) => {
								i++;
								const evt = e.SCHEDULES.map((c) => {
									return { ...c, id: e.EMPLOYEE_NO };
								});
								loadEventData = [...loadEventData, ...evt];
								return { id: e.EMPLOYEE_NO, title: `${e.EMPLOYEE_CNAME}(${e.NICKNAME})`, fcst: 176, act: '', group: e.TEAM_NAME || 'N/A', seq: parseInt(e.ORDER_BY), index: i, teamId: e.TEAM_ID, empname: e.EMPLOYEE_CNAME, company_id: e.COMPANY_ID, username: e.USERNAME };
							})
							.sort((a, b) => (a.seq > b.seq ? 1 : a.seq === b.seq ? (a.title < b.title ? 1 : -1) : -1));
						//successCallback(items);
						emptmp = emps.map((c, i) => {
							return { ...c, index: i + 1 };
						});
						datagroup = [...new Map(emps.map((item) => [item['group'], item])).values()];
						emp_group_store.getProxy().setData(datagroup);
						emp_group_store.load();
						//grouptmp=datagroup.map(e=>e.id);
						setdef(emptmp, successCallback);
						//ReaderToolBar();
						settitle();
						//$(".mybtn-selectdate").datepicker('setDate',calendar.view.activeStart);

						//calendar.render();
					});
			} else {
				let newgroup = Array.from($('.myselect-EMPgroup').find(':selected')).map((e) => e.value);
				defdatagroup = Array.from($('.myselect-EMPgroup').find(':selected')).map((e) => {
					return { id: e.value, group: e.text };
				});
				(grouptmp.toString() === newgroup.toString() && IsUpdate) || schedulerInitResource(newgroup, successCallback);
				grouptmp = newgroup;
			}
		} /* ,
        selectable:ac,
        editable:ac,
        droppable:ac, */,
	});

	//var queryMycalendar = document.querySelector("#Mycalendar");

	/* if(!browserHandler){   //舊版 Edge 不支援 ResizeObserver API
        const resize_ob = new ResizeObserver(entries =>calendar.render());
        resize_ob.observe(queryMycalendar);
    } */

	//queryMycalendar.addEventListener('mousedown',  e => hotkey = e);

	const queryMycalendar = document.querySelector('#Mycalendar');
	const resize_ob = new ResizeObserver((entries) => {
		setTimeout(() => {
			calendar.render();
			// $('[data-toggle="tooltip"]').tooltip('dispose');
			// $('[data-toggle="tooltip"]').tooltip();
			$('.tooltip').remove();
		}, 800);
	});
	resize_ob.observe(queryMycalendar);

	getprivilege().then((auth) => {
		ac = auth;
		calendar.setOption('selectable', ac);
		calendar.setOption('editable', ac);
		calendar.setOption('droppable', ac);
		calendar.setOption('dropAccept', ac ? '*' : 'Mynowork');
	});

	if (!document.querySelector('#MyInfoDilog')) {
		const g = document.createElement('div');
		g.setAttribute('id', 'MyInfoDilog');
		document.body.appendChild(g);
	}

	calendar.render();
};
